package fiarwebapplet;

/*
 * To change this template, choose Tools | Templates and open the template in
 * the editor.
 */
import fiarautoplayer.*;
import java.awt.Component;
import java.awt.Graphics;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.MalformedURLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

/**
 *
 * @author NL
 */
public class FIARApplet2 extends javax.swing.JApplet {

    /**
     * Initializes the applet FIARApplet
     */
    private final String CONST_XML_FILENAME = "http://www.cs.tau.ac.il/~nurlan/rlworkshop/brain.xml";
    private final String CONST_VER = "4.2";
    private final String CONST_REDBTN_TEXT = "Red (first)";
    private final String CONST_BLACKBTN_TEXT = "Black (second)";
    private final Integer MAX_ROWS = 6;
    private final Integer MAX_COLS = 8;
    private FIARLearnerState myLearnerState;
    private QFunctionApproximator myQFuncApproximator;
    private GreedyQPolicy myGreedyQPolicy;
    private RLGamer myGamer;
    private FIARState myState;
    private Color humanColor;
    private Color machineColor;
    private boolean bHumanTurn = false;
    int redScore = 0, blackScore = 0;
    private Integer[] top = {0, 0, 0, 0, 0, 0, 0, 0};

    @Override
    public void init() {
        /*
         * Set the Nimbus look and feel
         */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /*
         * If Nimbus (introduced in Java SE 6) is not available, stay with the
         * default look and feel. For details see
         * http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FIARApplet2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FIARApplet2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FIARApplet2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FIARApplet2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>


        /*
         * Create and display the applet
         */
        try {
            java.awt.EventQueue.invokeAndWait(new Runnable() {

                public void run() {
                    initComponents();
                }
            });
        } catch (Exception ex) {
            ex.printStackTrace();
        }



        jGameTable.setBackground(new java.awt.Color(204, 204, 204));
        jGameTable.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jGameTable.setModel(new javax.swing.table.DefaultTableModel(
                new FIARState().getGrid(),
                new String[]{
                    "", "", "", "", "", "", "", ""
                }) {

            boolean[] canEdit = new boolean[]{
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        });
        jGameTable.setEnabled(false);
        jGameTable.setGridColor(new java.awt.Color(255, 255, 255));
        jGameTable.setIntercellSpacing(new java.awt.Dimension(5, 5));
        jGameTable.setRowHeight(55);
        jGameTable.getTableHeader().setReorderingAllowed(false);
        jGameTable.addKeyListener(new java.awt.event.KeyAdapter() {

            public void keyReleased(java.awt.event.KeyEvent evt) {
                jGameTableKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jGameTable);
        jGameTable.getColumnModel().getColumn(0).setHeaderValue("");
        jGameTable.getColumnModel().getColumn(1).setHeaderValue("");
        jGameTable.getColumnModel().getColumn(2).setHeaderValue("");
        jGameTable.getColumnModel().getColumn(3).setHeaderValue("");
        jGameTable.getColumnModel().getColumn(4).setHeaderValue("");
        jGameTable.getColumnModel().getColumn(5).setHeaderValue("");
        jGameTable.getColumnModel().getColumn(6).setHeaderValue("");
        jGameTable.getColumnModel().getColumn(7).setHeaderValue("");
        jGameTable.setDefaultRenderer(Object.class, new TableCellRenderer() {

            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                if (table.getValueAt(Consts.MAX_ROWS - row - 1, column).equals(CellState.RED)) 
                return new JComponent() {
//                    cell.setBackground(java.awt.Color.BLACK);
//                    cell.paintComponents(null);
                    @Override
                    protected void paintComponent(Graphics g) {
                        
//                        Image img = new ImageIcon("image.jpg").getImage();
//                        Dimension size = new Dimension(img.getWidth(null), img.getHeight(null));
//                        setPreferredSize(size);
//                        setMinimumSize(size);
//                        setMaximumSize(size);
//                        setSize(size);
//                        setLayout(null);
//                        g.drawImage(img, 0, 0, null);
g.setColor(java.awt.Color.WHITE);
                        g.fillRect(0, 0, 300, 300);
                        g.setColor(java.awt.Color.red);
                        g.fillOval(1, 1, jGameTable.getRowHeight()-7, jGameTable.getRowHeight()-7);

                        super.paintComponent(g);
                    }
                };
                else if (table.getValueAt(Consts.MAX_ROWS - row - 1, column).equals(CellState.BLACK)) return new JComponent() {
                    @Override
                    protected void paintComponent(Graphics g) {
                        g.setColor(java.awt.Color.WHITE);
                        g.fillRect(0, 0, 300, 300);
                        g.setColor(java.awt.Color.black);
                        g.fillOval(1, 1, jGameTable.getRowHeight()-7, jGameTable.getRowHeight()-7);

                        super.paintComponent(g);
                    }
                };
                return new JComponent() {
                    @Override
                    protected void paintComponent(Graphics g) {
                        g.setColor(java.awt.Color.WHITE);
                        g.fillRect(0, 0, 300, 300);
//                        g.setColor(java.awt.Color.GRAY);
//                        g.drawOval(0, 0, jGameTable.getRowHeight()-5, jGameTable.getRowHeight()-5);

                        super.paintComponent(g);
                    }
                };

//                
//                JPanel cell = new JPanel();
//                cell.setVisible(true);
//                if (table.getValueAt(Consts.MAX_ROWS - row - 1, column).equals(CellState.BLACK)) {
//                    cell.setBackground(java.awt.Color.BLACK);
//                    cell.paintComponents(null);
//                } else if (table.getValueAt(Consts.MAX_ROWS - row - 1, column).equals(CellState.RED)) {
//                    cell.setBackground(java.awt.Color.RED);
//                } else {
//                    cell.setBackground(java.awt.Color.WHITE);
//
//                }
//
//                return cell;
            }
        });
        updateScores(0, 0);
        lblBrain.setText("Ver" + CONST_VER + ". Running from XML at: " + CONST_XML_FILENAME);
    }

    private void humanTurn() {
        bHumanTurn = true;
        //TODO NOTIFY PLAYER
    }

    /**
     * This method is called from within the init() method to initialize the
     * form. WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        buttonGroup4 = new javax.swing.ButtonGroup();
        buttonGroup5 = new javax.swing.ButtonGroup();
        buttonGroup6 = new javax.swing.ButtonGroup();
        buttonGroup7 = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        jGameTable = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        rdbtnRed = new javax.swing.JRadioButton();
        rdbtnBlack = new javax.swing.JRadioButton();
        jBtnStart = new javax.swing.JButton();
        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(32767, 0));
        jSeparator1 = new javax.swing.JSeparator();
        lblBrain = new javax.swing.JLabel();

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        jGameTable.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jGameTable.setModel(new javax.swing.table.DefaultTableModel(
            new FIARState().getGrid(),
            new String [] {
                "", "", "", "", "", "", "", ""
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jGameTable.setEnabled(false);
        jGameTable.setGridColor(new java.awt.Color(255, 255, 255));
        jGameTable.setIntercellSpacing(new java.awt.Dimension(5, 5));
        jGameTable.setRowHeight(26);
        jGameTable.getTableHeader().setReorderingAllowed(false);
        jGameTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jGameTableMouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jGameTableMouseReleased(evt);
            }
        });
        jGameTable.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jGameTableKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jGameTable);

        jLabel1.setText("Play as:");

        rdbtnRed.setBackground(new java.awt.Color(255, 255, 255));
        rdbtnRed.setText("Red (first)");
        rdbtnRed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbtnRedActionPerformed(evt);
            }
        });

        rdbtnBlack.setBackground(new java.awt.Color(255, 255, 255));
        rdbtnBlack.setSelected(true);
        rdbtnBlack.setText("Black (second)");
        rdbtnBlack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbtnBlackActionPerformed(evt);
            }
        });

        jBtnStart.setText("Play Game");
        jBtnStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnStartActionPerformed(evt);
            }
        });

        lblBrain.setText(" ");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(lblBrain, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(rdbtnBlack, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(rdbtnRed, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jBtnStart, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 491, Short.MAX_VALUE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(119, 119, 119)
                            .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jSeparator1, javax.swing.GroupLayout.DEFAULT_SIZE, 1, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 364, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(rdbtnRed))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rdbtnBlack))
                    .addComponent(jBtnStart, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jSeparator1, javax.swing.GroupLayout.DEFAULT_SIZE, 1, Short.MAX_VALUE)
                        .addGap(72, 72, 72))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblBrain, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jGameTableKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jGameTableKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jGameTableKeyReleased

    private void jBtnStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnStartActionPerformed
        startNewGame();



    }//GEN-LAST:event_jBtnStartActionPerformed

    private void rdbtnRedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbtnRedActionPerformed
        if (rdbtnRed.isSelected()) {
            rdbtnBlack.setSelected(false);
            updateScores(0, 0);
        } else {
            rdbtnBlack.setSelected(true);
        }
    }//GEN-LAST:event_rdbtnRedActionPerformed

    private void rdbtnBlackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbtnBlackActionPerformed
        if (rdbtnBlack.isSelected()) {
            rdbtnRed.setSelected(false);
        } else {
            rdbtnRed.setSelected(true);
        }
    }//GEN-LAST:event_rdbtnBlackActionPerformed

    private void jGameTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jGameTableMouseClicked
    }//GEN-LAST:event_jGameTableMouseClicked

    private void jGameTableMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jGameTableMouseReleased
        if (bHumanTurn) {
            int cellnum = (evt.getX() / (jGameTable.getWidth() / jGameTable.getColumnCount()));
            if (myState.putAt(cellnum, humanColor)) {
                Move lastMove = Move.ZeroBasedToMove(cellnum);
                System.err.println("clicked cell " + cellnum + ", move: " + lastMove.name());
                //updateTable(myState);
                putAt(cellnum, humanColor == Color.RED ? CellState.RED : CellState.BLACK);
                if (!checkWin(lastMove, humanColor)) {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(FIARApplet2.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    machineTurn();
                } else {
                    //startNewGame();
                }
            }
        }
    }//GEN-LAST:event_jGameTableMouseReleased
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.ButtonGroup buttonGroup4;
    private javax.swing.ButtonGroup buttonGroup5;
    private javax.swing.ButtonGroup buttonGroup6;
    private javax.swing.ButtonGroup buttonGroup7;
    private javax.swing.Box.Filler filler1;
    private javax.swing.JButton jBtnStart;
    public javax.swing.JTable jGameTable;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblBrain;
    private javax.swing.JRadioButton rdbtnBlack;
    private javax.swing.JRadioButton rdbtnRed;
    // End of variables declaration//GEN-END:variables

    private void updateTable(final FIARState state) {
        Runnable run = (new Runnable() {

            @Override
            public void run() {
                final DefaultTableModel model = (DefaultTableModel) jGameTable.getModel();
                model.setDataVector(state.getGrid(), new String[]{"", "", "", "", "", "", "", ""});
                model.fireTableDataChanged();
            }
        });
        invoke(run);
    }

    private void invoke(Runnable run) {
        if (SwingUtilities.isEventDispatchThread()) {
            run.run();
        } else {
            try {
                SwingUtilities.invokeAndWait(run);
                //SwingUtilities.invokeLater(run);
            } catch (InterruptedException ex) {
                Logger.getLogger(FIARApplet2.class.getName()).log(Level.SEVERE, null, ex);
            } catch (InvocationTargetException ex) {
                Logger.getLogger(FIARApplet2.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private FIARLearnerState loadPlayerFromXml() throws ParserConfigurationException, MalformedURLException, IOException, SAXException {

        return new FIARLearnerState(true, CONST_XML_FILENAME);
    }

    private void machineTurn() {
        bHumanTurn = false;

        Move lastMove = null;
        try {
            lastMove = myGamer.play(myState);
            putAt(lastMove.getcolNum(), machineColor == Color.RED ? CellState.RED : CellState.BLACK);
            //updateTable(myState);
            humanTurn();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        if (!checkWin(lastMove, machineColor)) {
            humanTurn();
        } else {
            //startNewGame();
        }

    }

    private boolean checkWin(Move lastMove, Color lastColor) {
        if (myState.hasWonAt(lastColor, lastMove)) {
            if (lastColor == Color.RED) {
                updateScores(redScore + 1, blackScore);
            } else {
                updateScores(redScore, blackScore + 1);
            }
            JOptionPane.showMessageDialog(rootPane, lastColor.name() + " wins!");

            bHumanTurn = false; //prevent extra play
            return true;
        }
        if (myState.isFull()) {
            JOptionPane.showMessageDialog(rootPane, "It's a tie!");
            bHumanTurn = false; //prevent extra play
            return true;
        }
        return false;
    }

    private void startNewGame() {
        humanColor = rdbtnBlack.isSelected() ? Color.BLACK : Color.RED;
        machineColor = rdbtnBlack.isSelected() ? Color.RED : Color.BLACK;
        try {
            myLearnerState = loadPlayerFromXml();

        } catch (ParserConfigurationException ex) {
            Logger.getLogger(FIARApplet2.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MalformedURLException ex) {
            Logger.getLogger(FIARApplet2.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FIARApplet2.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SAXException ex) {
            Logger.getLogger(FIARApplet2.class.getName()).log(Level.SEVERE, null, ex);
        }
        myQFuncApproximator = rdbtnBlack.isSelected() ? myLearnerState.GetFirstQLinearApproximation() : myLearnerState.GetSecondQLinearApproximation(); //take qfunction according to did we start or not
        myGreedyQPolicy = new GreedyQPolicy(myQFuncApproximator, myLearnerState.getEpsilon(), true);

        myGamer = new RLGamer(machineColor, myGreedyQPolicy);
        myState = new FIARState();

        jBtnStart.setText("Start New Game");

        //start game
        myState.reset();
        resetTable();

        //updateTable(myState);

        if (machineColor == Color.RED) { //we start 
            machineTurn();
            // do first move
        } else {
            humanTurn();
        }
    }

    private boolean putAt(int column, CellState gamer) {

        if (top[column] < MAX_ROWS) {
            jGameTable.setValueAt(gamer, top[column], column);
            //jGameTable.setValueAt(gamer, MAX_ROWS - 1 - top[column], column);
            //tableUI.setValueAt(gamer, MAX_ROWS - 1 - top[column], column);
            jGameTable.repaint(); //TODO CHECK
            top[column]++;

            return true;
        }
        return false;
    }

    public void resetTable() {
        for (int i = 0; i < MAX_ROWS; i++) {
            for (int j = 0; j < MAX_COLS; j++) {
                jGameTable.setValueAt(CellState._, i, j);
            }
        }

        for (int i = 0; i < MAX_COLS; i++) {
            top[i] = 0;
        }
    }

    private void updateScores(int red, int black) {
        redScore = red;
        blackScore = black;
        rdbtnRed.setText(CONST_REDBTN_TEXT + " - " + redScore + " points");
        rdbtnBlack.setText(CONST_BLACKBTN_TEXT + " - " + blackScore + " points");

    }
}
