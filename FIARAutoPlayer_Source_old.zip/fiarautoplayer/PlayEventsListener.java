package fiarautoplayer;

/**
 * Interface for a listener to play events when in play mode
 * @author NL
 */
public interface PlayEventsListener {
    /**
     * Inform an new game
     * @param role the player role in the new game
     */
    public void newGame(Color role);
    /**
     * Inform a board state change
     * @param boardState
     */
    public void stateChange(FIARState boardState);
    /**
     * Inform the result of a game
     * @param winner
     * @param boardState
     */
    public void OnGameOver(Color winner, FIARState boardState);
    
}
