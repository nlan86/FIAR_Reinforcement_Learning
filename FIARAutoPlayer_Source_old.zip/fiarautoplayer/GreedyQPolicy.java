/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fiarautoplayer;

import java.util.Random;

/**
 * Implementation of an epsilon greedy Q value policy
 *
 * @author sali
 */
public class GreedyQPolicy implements IAlgorithm {

    FIARFeatureExtractor featrureExtract = new FIARFeatureExtractor();
    private double epsilon;
    private static Random rand = new Random();
    private Minimax minimax;
    private final boolean useLookAhead;

    /**
     *
     */
    @Override
    public void initState() {
    }

    /**
     *
     * @param currentState
     * @param loserColor
     * @param reward
     * @throws Exception
     */
    @Override
    public void reportLoss(FIARState currentState, Color loserColor, int reward) throws Exception {
    }
    @Override
    public void reportWin(FIARState currentState, Color winnerColor, int reward) throws Exception{
    }
    private QFunctionApproximator qFunctionApproximator;

    public GreedyQPolicy(QFunctionApproximator Qapprox, double epsilon) {
        this(Qapprox, epsilon, false);
    }

    /**
     * Constructor - receives a Q Function Approximator and epsilon-greedy value
     *
     * @param Qapprox
     * @param epsilon
     */
    public GreedyQPolicy(QFunctionApproximator Qapprox, double epsilon, boolean useLookAhead) {
        qFunctionApproximator = Qapprox;
        minimax = new Minimax(Qapprox);
        this.epsilon = epsilon;
        this.useLookAhead = useLookAhead;
    }

    /**
     *
     * @return Q Function Approximator object
     */
    public QFunctionApproximator getqFunctionApproximator() {
        return qFunctionApproximator;
    }

    /**
     * Returns next move according to epsilon-greedy policy Chooses random move
     * with probability epsilon, or pre-calculated optimized move with 1-epsilon
     * prob.
     *
     * @param currentState
     * @param myColor
     * @return Move identifier (column) from 1 to 8
     * @throws Exception
     */
    public Move returnNextMove(FIARState currentState, Color myColor) throws Exception {
        Move winningMove = currentState.getWinningMove(myColor);
        if (winningMove != null) {
            return winningMove;
        }

        int chosenAction = -1;
        double chooseGreedy = rand.nextDouble();

        Integer[] legalMoves = currentState.getLegalMoves();
        if (chooseGreedy <= epsilon) { //random move with epsilon probab.
            int col = legalMoves[rand.nextInt(legalMoves.length)];
            chosenAction = col;
            return Move.ZeroBasedToMove(chosenAction);

        } else { //optimized move with 1-epsilon probab.
            int[] features = null;
            double maxEval = Double.NEGATIVE_INFINITY;

            double currentEvaluation;


            if (useLookAhead) {
                return minimax.returnNextMove(currentState, myColor);
            } else { 
                // choose first index at random so we won't bias left columns incase of eqaulity
                features = featrureExtract.extractFeatures(currentState, myColor);
                int startIndex = rand.nextInt(legalMoves.length);
                for (int i = startIndex, cnt = 0; cnt < legalMoves.length; cnt++, i = (i + 1) % legalMoves.length) {
                    int move = legalMoves[i];
                    currentEvaluation = qFunctionApproximator.Evaluate(move, features);
                    if (maxEval == Double.NEGATIVE_INFINITY || (currentEvaluation - maxEval) > Consts.PERCISION) {
                        maxEval = currentEvaluation;
                        chosenAction = move;
                    }
                }

                return Move.ZeroBasedToMove(chosenAction);
            }

        }



    }

    /**
     *
     * @return current epsilon value
     */
    public double getEpsilon() {
        return epsilon;
    }

    /**
     *
     * @param epsilon
     */
    public void setEpsilon(double epsilon) {
        this.epsilon = epsilon;
    }
}
