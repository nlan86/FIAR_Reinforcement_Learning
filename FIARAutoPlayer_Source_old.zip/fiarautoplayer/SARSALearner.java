package fiarautoplayer;

import java.util.logging.Level;
import java.util.logging.Logger;


/**
 * Class responsible for the implementation of SARSA Q-Learning algorithm. 
 * As it's an on policy algorithm we chose as it's policy an epsilon greedy Q policy
 * @author sali
 */
public class SARSALearner extends GreedyQPolicy {

    boolean updateMode = false; // we begin update only when we see first result of an action
    double StQtvalAfterUpdate = 0;
    Move lastMove = null;
    double gamma;
    int played;
    FIARFeatureExtractor featrureExtract = new FIARFeatureExtractor();
    HardCodedMoves hardCodedMoves = new HardCodedMoves();
    double lastUpdateDelta;;
    private int[] lastStateFeatures = null;

    /**
     * resets learner state
     * updates to the Q function are made only after result of the first move.
     * We keep the last move information as our state. 
     * When starting a new game we need to reset this state using this method.
     */
    @Override
    public void initState() {
        updateMode = false; // we begin update only when we see first result of an action
        StQtvalAfterUpdate = 0;
        lastStateFeatures = null;
        lastMove = null;
        lastUpdateDelta = Double.NEGATIVE_INFINITY;
        super.initState();
    }

    /**
     * Used to report a game which ended with a loss
     * When a game is over with the RLGamer using the SARSALearner algorithm as it's policy losing
     * it needs to inform the learner inorder to perform a Q update
     * @param currentState
     * @param loserColor
     * @param reward
     * @throws Exception
     */
    @Override
    public void reportLoss(FIARState currentState, Color loserColor, int reward) throws Exception {
        int[] currentStateFeatures = featrureExtract.extractFeatures(currentState, loserColor);
        runUpdateRule(reward, null, currentStateFeatures, true);
    }
    
    @Override
    public void reportWin(FIARState currentState, Color winnerColor, int reward) throws Exception{
          int[] currentStateFeatures = featrureExtract.extractFeatures(currentState, winnerColor);
        runUpdateRule(reward, null, currentStateFeatures, true);
    }

    /**
     * Main entry point.
     * This method uses either the HardCodedMoves (for bootstrapping) or the  greedy policy to 
     * get the next Move.
     * Then it perform the update rule as appropriate while updating the information about
     * the current move so it can be used during the next update.
     * @param currentState
     * @param myColor
     * @return chosen move
     * @throws Exception
     */
    @Override
    public Move returnNextMove(FIARState currentState, Color myColor) throws Exception {        
        Move nextMove = hardCodedMoves.getMove(currentState, myColor);

        if (nextMove == null) { // no hard coded move found
            nextMove = super.returnNextMove(currentState, myColor);
        }

        int[] currentStateFeatures = featrureExtract.extractFeatures(currentState, myColor);
        // we update the Q only after result of first move
        if (updateMode) {

            runUpdateRule(0, nextMove, currentStateFeatures, false);

            // now that we got the new Q approximation, we save it's value for this state for use in the next update
            StQtvalAfterUpdate = getqFunctionApproximator().Evaluate(nextMove.getcolNum(), currentStateFeatures);

            // todo delete
            if (Double.isInfinite(StQtvalAfterUpdate)) {
                Logger.getLogger(SARSALearner.class.getName()).log(Level.SEVERE, "-inf", "bla");
                throw new Exception("bla");
            }
        }

        lastStateFeatures = currentStateFeatures;
        lastMove = nextMove;
        updateMode = true;

        return nextMove;
    }

    private void runUpdateRule(int reward, Move nextMove, int[] currentStateFeatures, boolean terminating) throws Exception {
        double newQValue = (!terminating ? getqFunctionApproximator().Evaluate(nextMove.getcolNum(), currentStateFeatures) : 0);
        final double newAnnealedQValue = gamma * newQValue;

        //final double alpha = (1 / (1000 + Math.sqrt(played)));
        //final double alpha = (1 / (1 + Math.log(played + 10)));
        //final double alpha = (1 / (1 + Math.pow(played,1/5)));
        final double alpha = (1 / (1 + Math.sqrt(played/2)));
        if (Double.isInfinite(alpha) || Double.isNaN(alpha))
            throw new Exception("Alpha not a number. played: " + played);

        double updateWeight = alpha
                * (reward + newAnnealedQValue - StQtvalAfterUpdate);

        lastUpdateDelta = StrictMath.abs(newAnnealedQValue - StQtvalAfterUpdate);
                
        for (int i = 0; i < FIARFeatureExtractor.nFeatures; i++) {
            double updateDelta = updateWeight * lastStateFeatures[i];
            // todo delete
            if (Double.isNaN(updateDelta)) {
                Logger.getLogger(SARSALearner.class.getName()).log(Level.SEVERE, "updateWeight: " + updateWeight + ", played: " + played + " , alpha: " + Double.toString(alpha) + ", lastStateFeatures: " + lastStateFeatures[i] + ", StQtvalAfterUpdate" + StQtvalAfterUpdate, "bla");
                throw new Exception("played: " + played + " , alpha: " + Double.toString(alpha) + ", lastStateFeatures: " + lastStateFeatures[i] + ", StQtvalAfterUpdate" + StQtvalAfterUpdate);
            }

            final double oldWeight = getqFunctionApproximator().GetWeight(lastMove.getcolNum(), i);

            getqFunctionApproximator().UpdateWeight(lastMove.getcolNum(), i, oldWeight + updateDelta);
        }
    }

    /**
     * Constructs an instance of the learner using a preloaded Q and learning params
     * @param Qapprox Preloaded Q function representation
     * @param epsilon Exploration parameter
     * @param gamma Discount parameter
     * @param played Amount of games played so far to learn the preloaded Q used to calculate learning rate
     */
    public SARSALearner(QFunctionApproximator Qapprox, double epsilon, double gamma, int played) {
        super(Qapprox, epsilon);;
        this.gamma = gamma;
        this.played = played;

    }

    /**
     * 
     * @return Discount parameter
     */
    public double getGamma() {
        return gamma;
    }

    /**
     * Sets discount parameter
     * @param gamma
     */
    public void setGamma(double gamma) {
        this.gamma = gamma;
    }

    /**
     * 
     * @return Num of total games played to learn the Q approximation
     */
    public int getPlayed() {
        return played;
    }

    /**
     * Sets Num of total games played to learn the Q approximation
     * @param played
     */
    public void setPlayed(int played) {
        this.played = played;
    }

}
