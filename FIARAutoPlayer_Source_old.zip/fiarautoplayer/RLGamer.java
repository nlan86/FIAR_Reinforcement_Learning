package fiarautoplayer;

/**
 * This class represents a player in a 2 player board game
 * holds an IAlgorithm that implements the play policy
 * @author sali
 */
public class RLGamer {

    Color myColor;
    IAlgorithm algorithm;

    /**
     * constructor
     *
     * @param myColor: the players color
     * @param algorithm: the algorithm used to calculate the next move
     */
    public RLGamer(Color myColor, IAlgorithm algorithm) {
        this.myColor = myColor;
        this.algorithm = algorithm;
    }

    /**
     *
     * @return: the algoritm
     */
    public IAlgorithm getAlgorithm() {
        return algorithm;
    }

    /**
     * sets the algorithm
     *
     * @param algorithm
     */
    public void setAlgorithm(IAlgorithm algorithm) {
        this.algorithm = algorithm;
    }

    /**
     *
     * @return: the players Color
     */
    public Color getMyColor() {
        return myColor;
    }

    /**
     * sets the players color
     *
     * @param myColor
     */
    public void setMyColor(Color myColor) {
        this.myColor = myColor;
    }

    /*
     * the function sets a new game (whith the player with the color myColor),
     * the algorithms state is initialized
     */
    void newGame(Color myColor) {
        setMyColor(myColor);
        algorithm.initState();
    }

    /*
     * the function returns the next Move to be played (action to be chosen)
     */
    public Move play(FIARState state) throws Exception {
        Move move = algorithm.returnNextMove(state, myColor);
        state.putAt(move.getcolNum(), myColor);
        return move;
    }

    /*
     * if the player lost the game it reports to the algorithm
     */
    void endGame(FIARState state, int reward) throws Exception {
        if (reward < 0) {
            algorithm.reportLoss(state, myColor, reward);
        }
        else if (reward >0)
        {
            algorithm.reportWin(state, myColor, reward);
        }
    }
}
