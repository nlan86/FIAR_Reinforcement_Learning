package fiarautoplayer;

import java.util.Random;

/**
 * Class implementing a linear function approximator
 * Used for evaluation of linear function given a set of weights and features
 * @author sali
 */
public class LinearFunctionApproximator {
    static Random rand = new Random();
    double[] weights;
    /**
     * 
     * @param nFeatures: num of features in the board. All the weights are initialized to 1
     */
    public LinearFunctionApproximator(int nFeatures) {
        weights = new double[nFeatures];
        for (int i=0;i<weights.length;i++)
            weights[i] = rand.nextGaussian();// samples gaussian with mean 0 and std 1
            //weights[i]=1.0;
    }
    
    /**
     * 
     * @param preSetWeights: a constructor using a givven array of weights
     */
    public LinearFunctionApproximator(double[] preSetWeights){
        weights = preSetWeights;
    }
    
    /**
     *  the function updates the weigth of a feature
     * @param iFeature: an index of a feature
     * @param newWeight: the new weight of the featur
     */
    public void UpdateWeight(int iFeature, double newWeight){
        weights[iFeature] = newWeight;
    }
    
    /**
     * 
     * @param iFeature: an index of the array 
     * @return: returns the weight of the feature
     */
    public double GetWeight(int iFeature)
    {
        return   weights[iFeature];
    }
    
    /**
     * 
     * @param features: a features array
     * @return: the function returns the approximation (sum on i of feature(i)*weiths(i))
     */
    public double Evaluate(int[] features){
        if (features.length != weights.length)
            throw new ArrayIndexOutOfBoundsException("Feature vector must be the same size of weight vector");
        
        double val = 0;
        for (int i=0;i<features.length;i++){
            val += features[i]*weights[i];
        }
        return val;
    }
    
}
