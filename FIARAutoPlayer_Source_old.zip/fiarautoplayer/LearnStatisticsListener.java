package fiarautoplayer;

import java.util.List;

/**
 * Listener for collection of statistics at endplay 
 * @author sali
 */
public interface LearnStatisticsListener {
    
    public void onGameOver(Color winner, int nTurns, int nGamesPlayed, List<Integer> gameSequence, double maxUpdateDeltaInGame);
    
}
