/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fiarautoplayer;

import java.util.LinkedList;
import java.util.List;

/**
 * Main class to handle running games and learning process
 *
 * @author sali
 */
public class LearnManager {

    EpsilonUpdate epsilonUpdate = new EpsilonUpdate();
    FIARLearnerState learnerState;
    SARSALearner learnerRed;
    SARSALearner learnerBlack;
    ;
    RLGamer redGamer;
    RLGamer blackGamer;
    FIARState state;
    Color lastWinner;
    int lastNumTurns;
    double firstEpsilon;
    EpsilonUpdate.UpdateTypes epsilonUpdateType;
    double epsilonAnnealFactor;

    double maxUpdateDeltaInLastGame;
    public FIARLearnerState getLearnerState() {
        return learnerState;
    }

    /**
     * a cunstructor that receives a FIARLearnerState and as default there will
     * be no epsilon update (since not specified) - it will be constant
     * throughout the learning sequence
     *
     * @param learnerState
     */
    public LearnManager(FIARLearnerState learnerState) {
        this(learnerState, EpsilonUpdate.UpdateTypes.None);
    }

    /**
     *
     * @param learnerState
     * @param epsilonUpdateType
     */
    public LearnManager(FIARLearnerState learnerState, EpsilonUpdate.UpdateTypes epsilonUpdateType) {
        this.learnerState = learnerState;
        firstEpsilon = learnerState.getEpsilon();
        this.epsilonUpdateType = epsilonUpdateType;

        learnerRed = new SARSALearner(learnerState.GetFirstQLinearApproximation(), learnerState.getEpsilon(), learnerState.getGamma(), learnerState.getGamesPlayed());
        //learnerBlack = new SARSALearner(qFunctionApproximator, learnerState.getEpsilon(), learnerState.getGamma(), learnerState.getGamesPlayed());
        // todo delete made it a random player that knows to win
        //learnerBlack = new SARSALearner(new QFunctionApproximator(FIARFeatureExtractor.nFeatures, Consts.MAX_COLS), 1, learnerState.getGamma(), learnerState.getGamesPlayed());
        learnerBlack = new SARSALearner(learnerState.GetSecondQLinearApproximation(), learnerState.getEpsilon(), learnerState.getGamma(), learnerState.getGamesPlayed());

        redGamer = new RLGamer(Color.RED, learnerRed);
        blackGamer = new RLGamer(Color.BLACK, learnerBlack);

        state = new FIARState();
    }

    /**
     * this function is used when the update epsilon type is FactorAnnealed and
     * it sets the factor
     *
     * @param epsilonAnnealFactor: the factor that will be used to update the
     * epsilon
     */
    public void setEpsilonAnnealFactor(double epsilonAnnealFactor) {
        this.epsilonAnnealFactor = epsilonAnnealFactor;
    }

    /*
     * this function switches roles between the players (changes current player)
     */
    private static RLGamer toggleCurrent(RLGamer current, RLGamer first, RLGamer second) {
        return (current == first ? second : first);
    }


    /*
     * this function runs a single 4 in a row game
     */
    private void runSingleGame(List<Integer> gameSequence) throws Exception {
        gameSequence.clear();
        RLGamer first = redGamer;
        RLGamer second = blackGamer;
        maxUpdateDeltaInLastGame = 0;
        /*
         * // redGamer is the one actively learning so it should play half the
         * time as first and half as second if (learnerState.gamesPlayed % 2 ==
         * 0) { first = redGamer; second = blackGamer; } else { first =
         * blackGamer; second = redGamer;
        }
         */

        // Single Game loop
        lastNumTurns = 0;
        state.reset();
        RLGamer current = first;
        Move lastMove = current.play(state);
        gameSequence.add(lastMove.getcolNum());

        // Continue run until last player didn't win or tied with lastMove
        while (!state.hasWonAt(current.getMyColor(), lastMove) && !state.isFull()) {
            current = toggleCurrent(current, first, second);
            lastMove = current.play(state);
            
            if (maxUpdateDeltaInLastGame < learnerBlack.lastUpdateDelta)
                maxUpdateDeltaInLastGame = learnerBlack.lastUpdateDelta;
            else if (maxUpdateDeltaInLastGame < learnerRed.lastUpdateDelta)
                maxUpdateDeltaInLastGame = learnerBlack.lastUpdateDelta;
            
            gameSequence.add(lastMove.getcolNum());
            lastNumTurns++;
        }

        // check if ended with win or tie
        if (state.hasWonAt(current.getMyColor(), lastMove)) {
            current.endGame(state, Consts.WIN_REWARD);
            lastWinner = current.getMyColor();
            current = toggleCurrent(current, first, second);
            current.endGame(state, -Consts.WIN_REWARD);
        } else {
            first.endGame(state, 0);
            second.endGame(state, 0);
            lastWinner = null;
        }
    }

    /**
     * this function runs a learning sequence of nGampesToPlay games.
     *
     * @param nGamesToPlay: number of games to be played in the learning
     * sequence
     * @param sListener: a listener called at the end of each game in the
     * sequence, is used to update stats file
     * @throws Exception
     */
    public void runLearningSequence(int nGamesToPlay, LearnStatisticsListener sListener) throws Exception {

        int played = 0;

        learnerBlack.initState();
        learnerRed.initState();
        List<Integer> gameSequence = new LinkedList<Integer>();

        while (played < nGamesToPlay) {
            runSingleGame(gameSequence);

            learnerBlack.initState();
            learnerRed.initState();
            learnerBlack.setPlayed(learnerBlack.getPlayed() + 1);
            learnerRed.setPlayed(learnerRed.getPlayed() + 1);
            played++;
            learnerState.incGamesPlayed();

            learnerState.setEpsilon(updateEpsilon(learnerState.getGamesPlayed()));
            learnerBlack.setEpsilon(learnerState.getEpsilon());
            learnerRed.setEpsilon(learnerState.getEpsilon());

            if (played > 0 && played % 10 == 0) {
                learnerRed.getqFunctionApproximator().normalizeWeights();
                learnerBlack.getqFunctionApproximator().normalizeWeights();
            }

            sListener.onGameOver(lastWinner, lastNumTurns, learnerState.getGamesPlayed(), gameSequence, maxUpdateDeltaInLastGame);
        }
        learnerRed.getqFunctionApproximator().normalizeWeights();
        learnerBlack.getqFunctionApproximator().normalizeWeights();
    }

    /*
     * this function is used to update the epsilon. The update method is a
     * parameter specified at the beginning of the learning process
     */
    private double updateEpsilon(int played) {
        double newEpsilon;
        if (epsilonUpdateType == EpsilonUpdate.UpdateTypes.None) {
            newEpsilon = learnerState.getEpsilon();
        } else if (epsilonUpdateType == EpsilonUpdate.UpdateTypes.FactorAnnealed) {
            newEpsilon = epsilonUpdate.updateEpsilon(learnerState.getEpsilon(), epsilonAnnealFactor);
        } else if (epsilonUpdateType == EpsilonUpdate.UpdateTypes.ActionAnnealed) {
            newEpsilon = epsilonUpdate.updateEpsilon(firstEpsilon, played);
        } else {
            newEpsilon = learnerState.getEpsilon();
        }

        return newEpsilon;
    }
}
