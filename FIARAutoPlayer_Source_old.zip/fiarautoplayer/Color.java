package fiarautoplayer;

/**
 *Enum that represents player colors
 * @author sali
 */
public enum Color {
        RED,
        BLACK;
        
        /* the function receives a string representing a role in the game (black player or red player) and returns the matching Color*/
        static Color translate(String role)  {
        if (role.equals("black"))
        return Color.BLACK;
        else if (role.equals("red"))
            return Color.RED;
        else
            return null;
        }
        
        /* the function receives a Color and returns the Color of the opponent */
        static Color opponent(Color color) {
            if (color == RED) {
                return Color.BLACK;
            } else {
                return Color.RED;
            }
        }
}
