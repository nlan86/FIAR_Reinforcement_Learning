package fiarautoplayer;

import java.util.Random;

/**
 *Implementation of Minimax search algorithm
 * @author sali
 */
public class Minimax implements IAlgorithm {
    final int MAX_DEPTH = 3;
Random rand = new Random();

    private double bestQFromHere(FIARState originalState, Color myColor, Integer[] legalMoves) {
        int[] features = fExtractor.extractFeatures(originalState, myColor);
        double maxEval = Double.NEGATIVE_INFINITY;
        double currentEvaluation;
        // choose first index at random so we won't bias left columns incase of eqaulity
        int startIndex = rand.nextInt(legalMoves.length);
        for (int i = startIndex, cnt = 0; cnt < legalMoves.length; cnt++, i = (i + 1) % legalMoves.length) {
            int move = legalMoves[i];
            currentEvaluation = qFunctionApproximator.Evaluate(move, features);
            if (maxEval == Double.NEGATIVE_INFINITY || (currentEvaluation - maxEval) > Consts.PERCISION) {
                maxEval = currentEvaluation;
            }
        }
        
        return maxEval;
    }

    private boolean lessThan(double maxMoveValue, double worstMoveValue) {
        return maxMoveValue==Double.NEGATIVE_INFINITY  || 
           worstMoveValue == Double.POSITIVE_INFINITY ||
           (!Double.isInfinite(worstMoveValue) && !Double.isInfinite(maxMoveValue)) &&
           worstMoveValue - maxMoveValue  > Consts.PERCISION;
    }

    private boolean moreThan(double minMoveValue, double bestMoveValue) {
        return minMoveValue == Double.POSITIVE_INFINITY|| 
             bestMoveValue == Double.NEGATIVE_INFINITY || 
             (!Double.isInfinite(bestMoveValue) && !Double.isInfinite(minMoveValue)) && (minMoveValue - bestMoveValue) > Consts.PERCISION;
    }
    class MoveValuePair {

        public MoveValuePair(int move, double value) {
            this.move = move;
            this.value = value;
        }
        int move;
        double value;
    }
    FIARFeatureExtractor fExtractor = new FIARFeatureExtractor();

    @Override
    public void initState() {
    }

    @Override
    public void reportLoss(FIARState currentState, Color loserColor, int reward) throws Exception {
    }
    
    @Override
    public void reportWin(FIARState currentState, Color winnerColor, int reward) throws Exception{
    }

    @Override
    public Move returnNextMove(FIARState currentState, Color myColor) throws Exception {
        Color oppColor = Color.opponent(myColor);
        return Move.ZeroBasedToMove(MaxMove(currentState, oppColor, myColor, -1,MAX_DEPTH,Double.NEGATIVE_INFINITY,Double.POSITIVE_INFINITY).move);
    }
    QFunctionApproximator qFunctionApproximator;

    public Minimax(QFunctionApproximator q) {
        qFunctionApproximator = q;
    }

    MoveValuePair MaxMove(FIARState originalState, Color oppColor, Color myColor,int lastMove, int depth,double alpha, double beta) {
        MoveValuePair bestMoveValue = null;
        
        // stop criteria
        Integer[] legalMoves = originalState.getLegalMoves();
        if (lastMove != -1 && originalState.hasWonAt(oppColor, Move.ZeroBasedToMove(lastMove))) { // loss
            return new MoveValuePair(lastMove, Double.NEGATIVE_INFINITY);
        } else if (legalMoves.length == 0){ // tie
            return new MoveValuePair(lastMove, 0);
        } else if (depth ==0){
            return new MoveValuePair(lastMove, bestQFromHere(originalState, myColor, legalMoves));
        }
        
        int legalmove =-1;
        // choose first index at random so we won't bias left columns incase of eqaulity
        int startIndex = rand.nextInt(legalMoves.length);
        for (int i = startIndex, cnt = 0; cnt < legalMoves.length; cnt++, i = (i + 1) % legalMoves.length) {
            legalmove = legalMoves[i];
            /*FIARState hypotheticalState = null;
            try {
                hypotheticalState = (FIARState) originalState.clone();
            } catch (CloneNotSupportedException ex) {
                Logger.getLogger(Minimax.class.getName()).log(Level.SEVERE, null, ex);
            }*/

            FIARState hypotheticalState = originalState;
            hypotheticalState.putAt(legalmove, myColor);
            MoveValuePair minMoveValue = MinMove(hypotheticalState, oppColor, myColor,legalmove,depth-1,alpha,beta);
            hypotheticalState.removeAt(legalmove);
            
            if (bestMoveValue == null){
                bestMoveValue = new MoveValuePair( legalmove,  minMoveValue.value);
            }else if (moreThan(minMoveValue.value, bestMoveValue.value)) {
                bestMoveValue.value = minMoveValue.value;
                bestMoveValue.move = legalmove;
            }
            
            if (moreThan(bestMoveValue.value,alpha))
                alpha = bestMoveValue.value;
       //     if (lessThan(beta,alpha))
          //      break;
        }
        //return new MoveValuePair(bestMoveValue.move, alpha);
        return bestMoveValue;
    }

    MoveValuePair MinMove(FIARState originalState, Color oppColor, Color myColor,int lastMove, int depth,double alpha, double beta) {

        MoveValuePair worstMoveValue = null;

        Integer[] legalMoves = originalState.getLegalMoves();
        if (originalState.hasWonAt(myColor, Move.ZeroBasedToMove(lastMove))) {
            return new MoveValuePair(lastMove, Double.POSITIVE_INFINITY);
        } else if (legalMoves.length == 0){
            return new MoveValuePair(lastMove, 0);
        } else if (depth ==0){
            return new MoveValuePair(lastMove, bestQFromHere(originalState, myColor, legalMoves));
        }
        
        // choose first index at random so we won't bias left columns incase of eqaulity
        int legalmove =-1;
        int startIndex = rand.nextInt(legalMoves.length);
        for (int i = startIndex, cnt = 0; cnt < legalMoves.length; cnt++, i = (i + 1) % legalMoves.length) {
            legalmove = legalMoves[i];
            /*FIARState hypotheticalState = null;
            try {
                hypotheticalState = (FIARState) originalState.clone();
            } catch (CloneNotSupportedException ex) {
                Logger.getLogger(Minimax.class.getName()).log(Level.SEVERE, null, ex);
            }*/
            FIARState hypotheticalState = originalState;

            hypotheticalState.putAt(legalmove, oppColor);
            MoveValuePair maxMoveValue = MaxMove(hypotheticalState, oppColor, myColor, legalmove, depth-1,alpha,beta);
            hypotheticalState.removeAt(legalmove);

            if (worstMoveValue == null){
               worstMoveValue = new MoveValuePair(legalmove, maxMoveValue.value); 
            } else  if (lessThan(maxMoveValue.value, worstMoveValue.value) ) {
                worstMoveValue.value = maxMoveValue.value;
                worstMoveValue.move = legalmove;
            }
            
            if (lessThan(worstMoveValue.value,beta)){
                beta = worstMoveValue.value;
            }
            //if (lessThan(beta,alpha))
               // break;
        }
        //return new MoveValuePair(worstMoveValue.move, beta);
        return worstMoveValue;

    }
}
