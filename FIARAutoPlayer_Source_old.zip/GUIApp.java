
import fiarautoplayer.*;
import java.awt.Component;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

/**
 * Gui for the Reinforcement learning for Four in a row framework. Handles view
 * related tasks while offloading business logic to main Managers (GameManager,
 * LearnManager, TestManager)
 *
 * @author sali
 */
public class GUIApp extends javax.swing.JFrame {

    final static String DEAFULT_FILENAME = ".\\fiarplayer.xml";
    String filename = null;

    private void invoke(Runnable run) {
        if (SwingUtilities.isEventDispatchThread()) {
            run.run();
        } else {
            SwingUtilities.invokeLater(run);
        }
    }

    abstract class Task extends SwingWorker {

        String note;
    }

    /**
     * Runs the testManager in the swing worker thread and inform gui about
     * results informed using the TestStatisticsListener interface
     */
    class TestTask extends Task implements TestStatisticsListener {

        public TestTask(TestManager tManager, int nGamesToPlay) {
            this.tManager = tManager;
            this.nGamesToPlay = nGamesToPlay;
        }
        TestManager tManager;
        private final int nGamesToPlay;
        private final static int N_BATCH = 100;
        int nGames = 0;
        private int blackWonAsFirst = 0;
        private int blackWonAsSecond = 0;
        private int redkWonAsFirst = 0;
        private int redkWonAsSecond = 0;

        @Override
        protected Object doInBackground() {
            try {
                for (int i = 0; i < nGamesToPlay / N_BATCH && !isCancelled(); i++) {
                    tManager.runTestingSequence(N_BATCH, this);
                }

                if (!isCancelled() && nGamesToPlay % N_BATCH != 0) {
                    tManager.runTestingSequence(nGamesToPlay % N_BATCH, this);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(rootPane, stackTraceToString(ex), "Error ", JOptionPane.ERROR_MESSAGE);
            }

            return "Testing session over";
        }

        @Override
        public void onGameOver(Color firstPlayerColor, Color winnerColor) {
            if (firstPlayerColor == Color.RED) {
                if (winnerColor == Color.RED) {
                    redkWonAsFirst++;
                } else if (winnerColor == Color.BLACK) {
                    blackWonAsSecond++;
                }
            } else {
                if (winnerColor == Color.RED) {
                    redkWonAsSecond++;
                } else if (winnerColor == Color.BLACK) {
                    blackWonAsFirst++;
                }
            }
            nGames++;
            note = "Games played: " + nGames;
            setProgress(100 * (nGames / nGamesToPlay));
        }

        @Override
        protected void done() {
            String result = "Total games played: " + nGamesToPlay + "\nGames won by black player: \n     as first player: " + blackWonAsFirst + "\n     as second player: " + blackWonAsSecond
                    + "\nGames won by red player: \n     as first player: " + redkWonAsFirst + "\n     as second player: " + redkWonAsSecond
                    + "\n Ties; " + (nGames - blackWonAsFirst - blackWonAsSecond - redkWonAsFirst - redkWonAsSecond);
            if (!isCancelled()) {
                JOptionPane.showMessageDialog(rootPane, result, "Test results ", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }

    /**
     * Runs the LearnManager in the swing worker thread and informs gui about
     * results informed using the LearnStatisticsListener interface
     */
    class TrainTask extends Task implements LearnStatisticsListener {

        @Override
        protected void done() {
            syncViewWithLearnerState(learnerState);
            if (jSaveIncremental.isSelected()) {
                saveIncrementalVersion();
            }
            jStartTrainButton.setEnabled(true);
            System.gc();
        }

        private void saveIncrementalVersion() {
            if (filename == null) {
                filename = DEAFULT_FILENAME;
            }
            try {
                File f = new File(filename);

                learnerState.SaveToXmlFile(f.getParent() + File.separator + currVersion + "_" + f.getName());
                currVersion++;
            } catch (Exception ex) {
                Logger.getLogger(GUIApp.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        private final static int N_BATCH = 100;
        final static int RATE_UPDATE_INTERVAL = 100;
        final static int NUM_INCREMENTAL_VERSIONS = 20;
        public long time1 = new java.util.Date().getTime();
        public int gameCountPerTimeSlice = 0;
        private double currentGameRate = 0;
        private final LearnManager lManager;
        private final int nGamesToPlay;
        int nGames = 0;
        int currVersion = 0;
        LearnStatisticsFileWriter fileWriter;

        public TrainTask(LearnManager lManager, int nGamesToPlay) {
            this.lManager = lManager;
            this.nGamesToPlay = nGamesToPlay;
            try {
                fileWriter = new LearnStatisticsFileWriter(jTrainStatisticsFile.getText());
            } catch (IOException ex) {
                Logger.getLogger(GUIApp.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(rootPane, stackTraceToString(ex), "Error ", JOptionPane.ERROR_MESSAGE);
            }
            note = "Played 0 games, \ngameRate: --, curr epsilon: " + learnerState.getEpsilon() + ", version:0";
        }

        @Override
        protected Object doInBackground() {
            try {
                for (int i = 0; i < nGamesToPlay / N_BATCH && !isCancelled(); i++) {
                    lManager.runLearningSequence(N_BATCH, this);
                }

                if (!isCancelled() && (nGamesToPlay % N_BATCH) != 0) {
                    lManager.runLearningSequence(nGamesToPlay % N_BATCH, this);
                }

                fileWriter.finish();

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(rootPane, stackTraceToString(ex), "Error ", JOptionPane.ERROR_MESSAGE);
            }
            syncViewWithLearnerState(learnerState);
            return "Training session over";

        }

        @Override
        public void onGameOver(Color winner, int nTurns, int nGamesPlayed, List<Integer> gameSequence, double maxUpdateDeltaInLastGame) {
            gameCountPerTimeSlice++;
            nGames++;
            if (gameCountPerTimeSlice == RATE_UPDATE_INTERVAL) {
                long time2 = new java.util.Date().getTime();
                currentGameRate = ((double) RATE_UPDATE_INTERVAL / ((double) (time2 - time1))) * 1000;
                gameCountPerTimeSlice = 0;
                time1 = time2;
            }

            if (jSaveIncremental.isSelected() && nGames > 0 && (nGames % (nGamesToPlay / NUM_INCREMENTAL_VERSIONS)) == 0) {
                saveIncrementalVersion();
            }
            note = String.format("Played %d games,  \ngameRate: %f, curr epsilon: %f, version:%d", nGamesPlayed, currentGameRate, learnerState.getEpsilon(), currVersion);
            setProgress(nGames * 100 / nGamesToPlay);

            fileWriter.onGameOver(winner, nTurns, nGamesPlayed, gameSequence, maxUpdateDeltaInLastGame);
        }
    }
    GUIApp app = this;
    FIARLearnerState learnerState;

    static String stackTraceToString(Exception ex) {
        StringWriter sw = new StringWriter();
        ex.printStackTrace(new PrintWriter(sw));
        return sw.toString();
    }

    /**
     * Creates new form GUIApp
     */
    public GUIApp() throws Exception {
        learnerState = new FIARLearnerState();
        initComponents();

        GameManagerRLGamer.setGameEventsListener(
                new PlayEventsListener() {

                    Color myColor;
                    public int wins = 0;
                    public int loses = 0;

                    @Override
                    public void OnGameOver(Color winner, FIARState boardState) {
                        if (winner == myColor) {
                            wins++;
                        } else {
                            loses++;
                        }
                        updatePlayStatusLabel(wins, loses);
                    }

                    @Override
                    public void newGame(final Color role) {
                        myColor = role;
                        updateRole(role);
                    }

                    @Override
                    public void stateChange(FIARState boardState) {
                        updateTable(boardState);
                    }
                });

        syncViewWithLearnerState(learnerState);
    }

    private void syncViewWithLearnerState(final FIARLearnerState learnerState) {
        Runnable run = new Runnable() {

            @Override
            public void run() {
                jEpsilonField.setText(Double.toString(learnerState.getEpsilon()));
                jGammaField.setText(Double.toString(learnerState.getGamma()));
                jTotalPlayed.setText(Integer.toString(learnerState.getGamesPlayed()));
            }
        };
        invoke(run);
    }

    private void syncLearnerStateWithView() {
        learnerState.setEpsilon(Double.parseDouble(jEpsilonField.getText()));
        learnerState.setGamma(Double.parseDouble(jGammaField.getText()));
    }

    private void updateRole(final Color role) {
        Runnable run = (new Runnable() {

            @Override
            public void run() {
                /*
                 * Graphics gColorCanvas = jColorCanvas.getGraphics();
                 * gColorCanvas.setColor(role==Color.RED? java.awt.Color.RED :
                 * java.awt.Color.BLACK);
                 * gColorCanvas.fillOval(0,0,jColorCanvas.getWidth()-1,jColorCanvas.getHeight()-1);
                 */
                jColorCanvas.setBackground((role == Color.RED ? java.awt.Color.RED : java.awt.Color.BLACK));
            }
        });
        invoke(run);
    }

    private void updateTable(final FIARState state) {
        Runnable run = (new Runnable() {

            @Override
            public void run() {
                final DefaultTableModel model = (DefaultTableModel) jGameTable.getModel();
                model.setDataVector(state.getGrid(), new String[]{"", "", "", "", "", "", "", ""});
                model.fireTableDataChanged();
            }
        });
        invoke(run);
    }

    private void updatePlayStatusLabel(int wins, int loses) {
        final String status = String.format("Wins: %d, Loses: %d", wins, loses);
        Runnable run = new Runnable() {

            @Override
            public void run() {
                jGameStatusLabel.setText(status);
            }
        };
        invoke(run);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        epsilonUpdateGroup = new javax.swing.ButtonGroup();
        jLoadButton = new javax.swing.JButton();
        jSaveButton = new javax.swing.JButton();
        jTabbedPane = new javax.swing.JTabbedPane();
        jLearnPanel = new javax.swing.JPanel();
        jStartTrainButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTotalPlayed = new javax.swing.JLabel();
        jGammaField = new javax.swing.JTextField();
        jEpsilonField = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jGamesToPlayField = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jTrainStatisticsFile = new javax.swing.JTextField();
        jSaveIncremental = new javax.swing.JCheckBox();
        jepsilonNoUpdate = new javax.swing.JRadioButton();
        jepsilonAnnealed = new javax.swing.JRadioButton();
        jepsilonNumOfGames = new javax.swing.JRadioButton();
        jEpsilonAnnealFactor = new javax.swing.JTextField();
        jTestPanel = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jBlackLearnt = new javax.swing.JTextField();
        jRedLearnt = new javax.swing.JTextField();
        jTestNumGamesToPlay = new javax.swing.JTextField();
        jRunTestButton = new javax.swing.JButton();
        jPlayPanel = new javax.swing.JPanel();
        jColorCanvas = new java.awt.Canvas();
        jFieldPortNum = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jButtonStartPlay = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jGameTable = new javax.swing.JTable();
        jGameStatusLabel = new javax.swing.JLabel();
        jNewButton = new javax.swing.JButton();
        jSaveAsButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLoadButton.setText("Load...");
        jLoadButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jLoadButtonActionPerformed(evt);
            }
        });

        jSaveButton.setText("Save");
        jSaveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jSaveButtonActionPerformed(evt);
            }
        });

        jStartTrainButton.setText("Start Training");
        jStartTrainButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jStartTrainButtonActionPerformed(evt);
            }
        });

        jLabel1.setText("Total Played: ");

        jLabel2.setText("Gamma: ");

        jLabel3.setText("Epsilon: ");

        jTotalPlayed.setText("0");

        jGammaField.setText("1");

        jEpsilonField.setText("0.9");
        jEpsilonField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jEpsilonFieldActionPerformed(evt);
            }
        });

        jLabel4.setText("#Games to play: ");

        jGamesToPlayField.setText("10000");

        jLabel8.setText("Statistics Log File:");

        jTrainStatisticsFile.setText("file name of statistics log");

        jSaveIncremental.setSelected(true);
        jSaveIncremental.setText("Save incremental version");

        epsilonUpdateGroup.add(jepsilonNoUpdate);
        jepsilonNoUpdate.setSelected(true);
        jepsilonNoUpdate.setText("No update");

        epsilonUpdateGroup.add(jepsilonAnnealed);
        jepsilonAnnealed.setText("Annealed");

        epsilonUpdateGroup.add(jepsilonNumOfGames);
        jepsilonNumOfGames.setText("Num of games");

        jEpsilonAnnealFactor.setText("0.9999");

        javax.swing.GroupLayout jLearnPanelLayout = new javax.swing.GroupLayout(jLearnPanel);
        jLearnPanel.setLayout(jLearnPanelLayout);
        jLearnPanelLayout.setHorizontalGroup(
            jLearnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLearnPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jLearnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jLearnPanelLayout.createSequentialGroup()
                        .addGroup(jLearnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jLearnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jGammaField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jLearnPanelLayout.createSequentialGroup()
                                .addComponent(jEpsilonField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(26, 26, 26)
                                .addGroup(jLearnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jepsilonNumOfGames)
                                    .addComponent(jepsilonNoUpdate)
                                    .addGroup(jLearnPanelLayout.createSequentialGroup()
                                        .addComponent(jepsilonAnnealed)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jEpsilonAnnealFactor, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addComponent(jTotalPlayed, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(17, 17, 17))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jLearnPanelLayout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(18, 18, 18)
                        .addComponent(jTrainStatisticsFile, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jLearnPanelLayout.createSequentialGroup()
                        .addComponent(jStartTrainButton)
                        .addGap(26, 26, 26)
                        .addGroup(jLearnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSaveIncremental)
                            .addGroup(jLearnPanelLayout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jGamesToPlayField)
                                .addGap(13, 13, 13)))))
                .addGap(195, 195, 195))
        );
        jLearnPanelLayout.setVerticalGroup(
            jLearnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLearnPanelLayout.createSequentialGroup()
                .addGroup(jLearnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jLearnPanelLayout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addGroup(jLearnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jTotalPlayed))
                        .addGap(18, 18, 18)
                        .addGroup(jLearnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(jGammaField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jLearnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(jEpsilonField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jLearnPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jepsilonNoUpdate)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jLearnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jepsilonAnnealed)
                    .addComponent(jEpsilonAnnealFactor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jepsilonNumOfGames)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addGroup(jLearnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jTrainStatisticsFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jLearnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jLearnPanelLayout.createSequentialGroup()
                        .addComponent(jSaveIncremental)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jLearnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(jGamesToPlayField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jLearnPanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jStartTrainButton)))
                .addContainerGap())
        );

        jTabbedPane.addTab("Learn", jLearnPanel);

        jLabel6.setText("Black learnt parameters");

        jLabel7.setText("Red learnt parameters");

        jLabel11.setText("Num of games");

        jBlackLearnt.setText("file name");

        jRedLearnt.setText("file name");
        jRedLearnt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRedLearntActionPerformed(evt);
            }
        });

        jTestNumGamesToPlay.setText("1000");
        jTestNumGamesToPlay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTestNumGamesToPlayActionPerformed(evt);
            }
        });

        jRunTestButton.setText("Run Test");
        jRunTestButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRunTestButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jTestPanelLayout = new javax.swing.GroupLayout(jTestPanel);
        jTestPanel.setLayout(jTestPanelLayout);
        jTestPanelLayout.setHorizontalGroup(
            jTestPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jTestPanelLayout.createSequentialGroup()
                .addGroup(jTestPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jTestPanelLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jTestPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jLabel11))
                        .addGap(18, 18, 18)
                        .addGroup(jTestPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jBlackLearnt, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                            .addComponent(jRedLearnt)
                            .addComponent(jTestNumGamesToPlay)))
                    .addGroup(jTestPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jRunTestButton)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jTestPanelLayout.setVerticalGroup(
            jTestPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jTestPanelLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jTestPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jBlackLearnt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jTestPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jRedLearnt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jTestPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTestNumGamesToPlay, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addGap(18, 18, 18)
                .addComponent(jRunTestButton)
                .addContainerGap(147, Short.MAX_VALUE))
        );

        jTabbedPane.addTab("Test", jTestPanel);

        jColorCanvas.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jColorCanvas.setEnabled(false);

        jFieldPortNum.setText("9003");

        jLabel5.setText("Role:");

        jLabel10.setText("port:");

        jButtonStartPlay.setMnemonic('S');
        jButtonStartPlay.setText("Start");
        jButtonStartPlay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonStartPlayActionPerformed(evt);
            }
        });

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        jGameTable.setBackground(new java.awt.Color(204, 204, 204));
        jGameTable.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jGameTable.setModel(new javax.swing.table.DefaultTableModel(
            GameManagerRLGamer.getBoardState().getGrid(),
            new String [] {
                "", "", "", "", "", "", "", ""
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jGameTable.setEnabled(false);
        jGameTable.setGridColor(new java.awt.Color(255, 255, 255));
        jGameTable.setIntercellSpacing(new java.awt.Dimension(5, 5));
        jGameTable.setRowHeight(26);
        jGameTable.getTableHeader().setReorderingAllowed(false);
        jGameTable.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jGameTableKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jGameTable);
        jGameTable.getColumnModel().getColumn(0).setHeaderValue("");
        jGameTable.getColumnModel().getColumn(1).setHeaderValue("");
        jGameTable.getColumnModel().getColumn(2).setHeaderValue("");
        jGameTable.getColumnModel().getColumn(3).setHeaderValue("");
        jGameTable.getColumnModel().getColumn(4).setHeaderValue("");
        jGameTable.getColumnModel().getColumn(5).setHeaderValue("");
        jGameTable.getColumnModel().getColumn(6).setHeaderValue("");
        jGameTable.getColumnModel().getColumn(7).setHeaderValue("");
        jGameTable.setDefaultRenderer(Object.class, new TableCellRenderer() {

            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                JPanel cell = new JPanel();
                cell.setVisible(true);
                if (table.getValueAt(Consts.MAX_ROWS - row -1, column).equals(CellState.BLACK)) {
                    cell.setBackground(java.awt.Color.BLACK);
                } else if (table.getValueAt(Consts.MAX_ROWS - row -1, column).equals(CellState.RED)) {
                    cell.setBackground(java.awt.Color.RED);
                } else {
                    cell.setBackground(java.awt.Color.WHITE);

                }

                return cell;
            }
        });

        jGameStatusLabel.setText("Wins: 0, Loses: 0");

        javax.swing.GroupLayout jPlayPanelLayout = new javax.swing.GroupLayout(jPlayPanel);
        jPlayPanel.setLayout(jPlayPanelLayout);
        jPlayPanelLayout.setHorizontalGroup(
            jPlayPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPlayPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPlayPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 262, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPlayPanelLayout.createSequentialGroup()
                        .addGroup(jPlayPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jGameStatusLabel)
                            .addGroup(jPlayPanelLayout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jFieldPortNum, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButtonStartPlay)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jColorCanvas, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(488, 488, 488)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPlayPanelLayout.setVerticalGroup(
            jPlayPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPlayPanelLayout.createSequentialGroup()
                .addGroup(jPlayPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPlayPanelLayout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPlayPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPlayPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPlayPanelLayout.createSequentialGroup()
                                .addGroup(jPlayPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jFieldPortNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel10)
                                    .addComponent(jButtonStartPlay))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jGameStatusLabel))
                            .addGroup(jPlayPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jColorCanvas, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel5)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        jTabbedPane.addTab("Play", jPlayPanel);

        jNewButton.setText("New");
        jNewButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jNewButtonActionPerformed(evt);
            }
        });

        jSaveAsButton.setText("Save As...");
        jSaveAsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jSaveAsButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLoadButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSaveButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSaveAsButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jNewButton))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jTabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(25, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLoadButton)
                    .addComponent(jSaveButton)
                    .addComponent(jNewButton)
                    .addComponent(jSaveAsButton))
                .addGap(24, 24, 24))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jSaveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jSaveButtonActionPerformed
        syncLearnerStateWithView();
        int res;
        JFileChooser jfc = null;
        if (filename == null) {
            jfc = new JFileChooser();
            res = jfc.showSaveDialog(app);
            if (res == JFileChooser.APPROVE_OPTION) {
                filename = jfc.getSelectedFile().getPath();
            }
        } else {
            res = JFileChooser.APPROVE_OPTION;
        }

        if (res == JFileChooser.APPROVE_OPTION) {
            try {
                learnerState.SaveToXmlFile(filename);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(rootPane, stackTraceToString(ex), "Error saving file " + filename, JOptionPane.ERROR_MESSAGE);
                Logger.getLogger(GUIApp.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_jSaveButtonActionPerformed

    private void jEpsilonFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jEpsilonFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jEpsilonFieldActionPerformed

    private void jStartTrainButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jStartTrainButtonActionPerformed
        jStartTrainButton.setEnabled(false);
        syncLearnerStateWithView();

        EpsilonUpdate.UpdateTypes epsUpdate;
        if (jepsilonNoUpdate.isSelected()) {
            epsUpdate = EpsilonUpdate.UpdateTypes.None;
        } else if (jepsilonAnnealed.isSelected()) {
            epsUpdate = EpsilonUpdate.UpdateTypes.FactorAnnealed;
        } else {
            epsUpdate = EpsilonUpdate.UpdateTypes.ActionAnnealed;
        }

        final LearnManager lManager = new LearnManager(learnerState, epsUpdate);
        if (jepsilonAnnealed.isSelected()) {
            lManager.setEpsilonAnnealFactor(Double.parseDouble(jEpsilonAnnealFactor.getText()));
        }

        final int nGamesToPlay = Integer.parseInt(jGamesToPlayField.getText());
        TrainTask trainTask = new TrainTask(lManager, nGamesToPlay);
        showTaskProgressDialog(app, trainTask, "Training...", 0);
        trainTask.execute();
    }//GEN-LAST:event_jStartTrainButtonActionPerformed

    private void jLoadButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jLoadButtonActionPerformed
        JFileChooser jfc = new JFileChooser();
        int res = jfc.showOpenDialog(rootPane);
        if (res == JFileChooser.APPROVE_OPTION) {
            filename = jfc.getSelectedFile().getPath();
            try {
                learnerState = new FIARLearnerState(filename);

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(rootPane, stackTraceToString(ex), "Error opening file " + filename, JOptionPane.ERROR_MESSAGE);
                Logger.getLogger(GUIApp.class.getName()).log(Level.SEVERE, null, ex);
            }

            syncViewWithLearnerState(learnerState);
        }


    }//GEN-LAST:event_jLoadButtonActionPerformed

    private void jButtonStartPlayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonStartPlayActionPerformed
        syncLearnerStateWithView();
        GameManagerRLGamer.setLearnerState(this.learnerState);

        Thread t1 = new Thread(new Runnable() {

            @Override
            public void run() {
                List<String> nargs = new ArrayList<String>();

                nargs.add(jFieldPortNum.getText());
                nargs.add("fiarautoplayer.GameManagerRLGamer");

                player.gamer.statemachine.sadna.SadnaGamer.main(nargs.toArray(new String[]{}));
            }
        });

        t1.start();
        jButtonStartPlay.setEnabled(false);
    }//GEN-LAST:event_jButtonStartPlayActionPerformed

    private void jGameTableKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jGameTableKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jGameTableKeyReleased

    private void jRedLearntActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRedLearntActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRedLearntActionPerformed

    private void jTestNumGamesToPlayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTestNumGamesToPlayActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTestNumGamesToPlayActionPerformed

    private void jRunTestButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRunTestButtonActionPerformed
        try {
            File redConf = new File(jRedLearnt.getText());
            File blackConf = new File(jBlackLearnt.getText());
            if (!redConf.exists()) {
                JOptionPane.showMessageDialog(rootPane, "red features file does not exist", "Error " + redConf.getPath(), JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (!blackConf.exists()) {
                JOptionPane.showMessageDialog(rootPane, "black features file does not exist", "Error " + blackConf.getPath(), JOptionPane.ERROR_MESSAGE);
                return;
            }


            FIARLearnerState learnerStateBlack = new FIARLearnerState(blackConf.getPath());
            FIARLearnerState learnerStateRed = new FIARLearnerState(redConf.getPath());

            final TestManager tManager = new TestManager(learnerStateBlack, learnerStateRed);

            final int nGamesToPlay = Integer.parseInt(jTestNumGamesToPlay.getText());

            TestTask testTask = new TestTask(tManager, nGamesToPlay);
            showTaskProgressDialog(app, testTask, "Testing...", 0);
            testTask.execute();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(rootPane, stackTraceToString(ex), "Error ", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jRunTestButtonActionPerformed

    private void jNewButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jNewButtonActionPerformed
        try {
            learnerState = new FIARLearnerState();
        } catch (SAXException ex) {
            Logger.getLogger(GUIApp.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(GUIApp.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(GUIApp.class.getName()).log(Level.SEVERE, null, ex);
        }
        filename = null;
        syncViewWithLearnerState(learnerState);
    }//GEN-LAST:event_jNewButtonActionPerformed

    private void jSaveAsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jSaveAsButtonActionPerformed
        syncLearnerStateWithView();
        int res;
        JFileChooser jfc = null;

        jfc = new JFileChooser();
        res = jfc.showSaveDialog(app);
        if (res == JFileChooser.APPROVE_OPTION) {
            filename = jfc.getSelectedFile().getPath();

            try {
                learnerState.SaveToXmlFile(filename);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(rootPane, stackTraceToString(ex), "Error saving file " + filename, JOptionPane.ERROR_MESSAGE);
                Logger.getLogger(GUIApp.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_jSaveAsButtonActionPerformed

    private void showTaskProgressDialog(Component parent, final Task worker,
            String title, int startValue) {


        /*
         * This is final because we are making use of it in the anonymous inner
         * class created by the next statement in this method.
         */
        final ProgressMonitor monitor = new ProgressMonitor(parent, title, "",
                startValue, 100);
        monitor.setMillisToPopup(10);
        monitor.setMillisToDecideToPopup(10);
        /*
         * We add a property change listener to our worker which will monitor
         * the progress of the worker. This also allows us to check if the user
         * has cancelled the task and close the dialog and stop the task.
         */
        worker.addPropertyChangeListener(new PropertyChangeListener() {

            @Override
            public void propertyChange(PropertyChangeEvent evt) {

                int progress = worker.getProgress();
                monitor.setNote(worker.note);
                monitor.setProgress(progress);

                if (monitor.isCanceled() || worker.isDone()) {
                    if (monitor.isCanceled()) {
                        worker.cancel(false);
                    }
                    monitor.close();
                }
            }
        });
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /*
         * Set the Nimbus look and feel
         */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /*
         * If Nimbus (introduced in Java SE 6) is not available, stay with the
         * default look and feel. For details see
         * http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUIApp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUIApp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUIApp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUIApp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        try {
            FileHandler fh = new FileHandler("d:\\eli\\fiar\\MyLogFile.log", true);
            Logger logger = Logger.getLogger(SARSALearner.class.getName());
            logger.addHandler(fh);
            logger.setLevel(Level.ALL);
            SimpleFormatter formatter = new SimpleFormatter();
            fh.setFormatter(formatter);
        } catch (Exception e) {
        }
        /*
         * Create and display the form
         */
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                try {
                    new GUIApp().setVisible(true);
                } catch (Exception ex) {
                    Logger.getLogger(GUIApp.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup epsilonUpdateGroup;
    private javax.swing.JTextField jBlackLearnt;
    private javax.swing.JButton jButtonStartPlay;
    public java.awt.Canvas jColorCanvas;
    private javax.swing.JTextField jEpsilonAnnealFactor;
    private javax.swing.JTextField jEpsilonField;
    private javax.swing.JTextField jFieldPortNum;
    private javax.swing.JLabel jGameStatusLabel;
    public javax.swing.JTable jGameTable;
    private javax.swing.JTextField jGamesToPlayField;
    private javax.swing.JTextField jGammaField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    public javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jLearnPanel;
    private javax.swing.JButton jLoadButton;
    private javax.swing.JButton jNewButton;
    private javax.swing.JPanel jPlayPanel;
    private javax.swing.JTextField jRedLearnt;
    private javax.swing.JButton jRunTestButton;
    private javax.swing.JButton jSaveAsButton;
    private javax.swing.JButton jSaveButton;
    private javax.swing.JCheckBox jSaveIncremental;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton jStartTrainButton;
    private javax.swing.JTabbedPane jTabbedPane;
    private javax.swing.JTextField jTestNumGamesToPlay;
    private javax.swing.JPanel jTestPanel;
    private javax.swing.JLabel jTotalPlayed;
    private javax.swing.JTextField jTrainStatisticsFile;
    private javax.swing.JRadioButton jepsilonAnnealed;
    private javax.swing.JRadioButton jepsilonNoUpdate;
    private javax.swing.JRadioButton jepsilonNumOfGames;
    // End of variables declaration//GEN-END:variables
}
