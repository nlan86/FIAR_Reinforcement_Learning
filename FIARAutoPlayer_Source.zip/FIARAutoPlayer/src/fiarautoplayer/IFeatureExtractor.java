package fiarautoplayer;

/**
 * Interface for feature extraction from board according to color and current state
 * @author sali
 */
public interface  IFeatureExtractor {
    /**
     * @param state state of the board
     * @param myColor color of player in respect to which features are extracted
     * @return array of integer values that represents the board
     * @throws Exception 
     */
    int[] extractFeatures(FIARState state, Color myColor) throws Exception;
}
