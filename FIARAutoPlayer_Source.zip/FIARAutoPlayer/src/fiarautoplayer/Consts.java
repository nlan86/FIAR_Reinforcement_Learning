package fiarautoplayer;

/**
 * Various game and xml constants
 * @author sali
 */
public class Consts {
    public static final int MAX_ROWS = 6;
    public static final int MAX_COLS = 8;
    public static final int DEFAULT_GAMES_PLAYED = 0;
    public static final double DEFAULT_GAMMA = 1.0D;
    public static final double DEFAULT_EPSILON = 0.9D;
    
    public static final double PERCISION = 0.000001D;
    
    public static final String XML_PLAY_CONFIG_FILENAME = "player_config.xml";
    public static final String XML_ActionQApprox = "ActionQApproximator";
    public static final String XML_FirstQLinearApprox =  "FirstQLinearApproximation";
    public static final String XML_SecondQLinearApprox =  "SecondQLinearApproximation";
    public static final String XML_GLOBAL_PARAMS =  "GlobalParameters";
    public static final String XML_GLOBAL_PARAMS_GAMMA =  "Gamma";
    public static final String XML_GLOBAL_PARAMS_GAMESPLAYED = "GamesPlayed";
    static String XML_GLOBAL_PARAMS_EPSILON = "Epsilon";
    public static final String XML_TAG_WEIGHT = "weight";
    public static final String XML_TAG_NUM_OF_FEATURES = "numOfFeatures";
    public static final String XML_TAG_NUM_OF_ACTIONS = "numOfActions";
    
    public static final int WIN_REWARD=1;
    
}