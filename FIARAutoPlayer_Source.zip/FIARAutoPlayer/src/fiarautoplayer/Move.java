package fiarautoplayer;

/**
 * Represents possible moves on the board (ONE till EIGHT)
 * @author sali
 */
public enum Move {
    ONE(0),
    TWO(1),
    THREE(2),
    FOUR(3),
    FIVE(4),
    SIX(5),
    SEVEN(6),
    EIGHT(7),
    START(-1);
    private int colNum;

    /**
     *
     * @return Integer one-based column representation
     */
    public int getcolNum() {
        return colNum;
    }

    /**
     *
     * @return column in one-based form
     */
    public int getcolNumOneBased() {
        return colNum + 1;
    }

    /*
     * Move Constructor. Receives one-based column number
     */
    Move(int colNum) {
        this.colNum = colNum;
    }

    /**
     *
     * @param i
     * @return Zero-based column representation as one-based move enum
     */
    public static Move ZeroBasedToMove(int i) {
        switch (i) {
            case 0:
                return ONE;
            case 1:
                return TWO;
            case 2:
                return THREE;
            case 3:
                return FOUR;
            case 4:
                return FIVE;
            case 5:
                return SIX;
            case 6:
                return SEVEN;
            case 7:
                return EIGHT;
        }

        return null;
    }

    /**
     *
     * @param i
     * @return Move enum representing column number. Moves are one-based so Move name is synonymous with number
     */
    public static Move OneBasedToMove(int i) {
        switch (i) {
            case 1:
                return ONE;
            case 2:
                return TWO;
            case 3:
                return THREE;
            case 4:
                return FOUR;
            case 5:
                return FIVE;
            case 6:
                return SIX;
            case 7:
                return SEVEN;
        }

        return EIGHT;
    }
}
