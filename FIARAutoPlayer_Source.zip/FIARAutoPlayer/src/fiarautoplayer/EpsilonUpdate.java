package fiarautoplayer;

/**
 * Class in charge of managing epsilon policy over time
 *
 * @author Shanee Lavi
 */
public class EpsilonUpdate {

    public enum UpdateTypes {

        None,
        FactorAnnealed,
        ActionAnnealed
    }

    /**
     *
     * @param epsilon: the current value of epsilon
     * @param constant: the param used to reduce epsilon
     * @return: a new epsilon using a reduction function - the previous epsilon
     * multiplied by a factor
     */
    public double updateEpsilon(double epsilon, double constant) {
        return constant * epsilon;
    }

    /**
     *
     * @param startingEpsilon: the value of epsilon which we started the
     * algorithm with
     * @param gameNum: num of game in the current learning session
     * @return: a new epsilon using an epsilon-decreasing strategy
     */
    public double updateEpsilon(double startingEpsilon, int gameNum) {
        return (startingEpsilon * (double) Math.log(gameNum)) / (double) Math.sqrt(Math.sqrt(gameNum));
    }
}
