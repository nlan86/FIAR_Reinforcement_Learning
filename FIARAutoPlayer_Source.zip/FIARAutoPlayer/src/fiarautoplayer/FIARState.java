package fiarautoplayer;

import java.util.Set;
import java.util.TreeSet;

/**
 * Representation of board state
 *
 * @author NL
 */
public class FIARState implements Cloneable {

    private CellState[][] grid = new CellState[Consts.MAX_ROWS][Consts.MAX_COLS];
    private Integer[] top = new Integer[Consts.MAX_COLS];
    private Set<Integer> legalMoves = new TreeSet<Integer>();

    @Override
    public Object clone() throws CloneNotSupportedException {
        FIARState cloned = new FIARState();
        for (int i = 0; i < Consts.MAX_COLS; i++) {
            cloned.top[i] = top[i];
        }

        for (int lm : this.legalMoves) {
            cloned.legalMoves.add(lm);
        }

        for (int i = 0; i < Consts.MAX_COLS; i++) {
            for (int j = 0; j < Consts.MAX_ROWS; j++) {
                cloned.grid[j][i] = this.grid[j][i];
            }
        }

        return cloned;
    }

    /**
     * a constructron that creates a new enpty board
     */
    public FIARState() {
        reset();
    }

    /**
     *
     * @param grid: a board
     * @param top: an array of the first free index in each column
     * @param legalMoves: a set of leagal moves (columns that can be chosen)
     */
    public void setState(CellState[][] grid, Integer[] top, Set<Integer> legalMoves) {
        this.grid = grid;
        this.top = top;
        this.legalMoves = legalMoves;
    }

    /**
     *
     * @param col: a colun number
     * @return: a boolean which indicated if a column is a legal action in the
     * current board state
     */
    public boolean isLegalMove(int col) {
        return (col >= 0 && col < Consts.MAX_COLS && top[col] < Consts.MAX_ROWS);
    }

    /**
     *
     * @return: returns an array of legal moves (columns that can be chosen)
     */
    public Integer[] getLegalMoves() {
        return legalMoves.toArray(new Integer[legalMoves.size()]);
    }

    /**
     *adds a players disc onto the board at col
     * @param col: a column number
     * @param myColor: the players disk color
     * @return: returns true if successfully added a myColor colored disk to
     * column col, else false
     */
    public boolean putAt(int col, Color myColor) {
        if (isLegalMove(col)) {
            grid[top[col]][col] = CellState.translate(myColor);
            top[col]++;

            if (!isLegalMove(col)) {
                legalMoves.remove(col);
            }
            return true;
        }
        return false;
    }
    
    /**
     * removes the top disc at col
     * @param col
     * @return true if there was a disc to remove, false if the column was empty
     */
    public boolean removeAt(int col){
        if (top[col] !=0){
            if (top[col]==Consts.MAX_ROWS)
                legalMoves.add(col);
            
            top[col]--;
            grid[top[col]][col] = CellState._;
            return true;
        }
        
        return false;
    }

    /**
     *
     * @return: the current game board
     */
    public CellState[][] getGrid() {
        return grid;
    }

    /**
     * the function resets the current state (board) to an empty board
     */
    public void reset() {
        for (int i = 0; i < Consts.MAX_ROWS; i++) {
            for (int j = 0; j < Consts.MAX_COLS; j++) {
                grid[i][j] = CellState._;
            }
        }

        legalMoves.clear();
        for (int i = 0; i < Consts.MAX_COLS; i++) {
            top[i] = 0;
            legalMoves.add(i);
        }
    }

    /**
     *
     * @param col: a column number
     * @param row: a row number
     * @return: the state (color of the disk) of the cell (row, col)
     */
    public CellState getCellState(int col, int row) {
        return grid[row][col];
    }

    /**
     *
     * @param col: column num
     * @return: returns the first available row in the column col
     */
    public int getFirstFreeIndexOfColumn(int col) {
        return top[col];
    }

    /**
     *
     * @param color: the players color
     * @param lastMovePlayerMade: a Move whick indicates the last action
     * (column)
     * @return: returns true if the last move played completed 4 in a row
     */
    public boolean hasWonAt(Color color, Move lastMovePlayerMade) {
        int col = lastMovePlayerMade.getcolNum();
        int row = top[col] - 1;

        return CompletesToN(color, 4, row, col);
    }

    /**
     *
     * @return: the function returns true if the board is full and there is a
     * tie
     */
    public boolean isFull() {
        boolean full = true;

        for (int i = 0; i < Consts.MAX_COLS; i++) {
            full = full && (!isLegalMove(i));
        }

        return full;
    }

    /**
     *
     * @return: the function returns true if the board is empty
     */
    public boolean isEmpty() {
        boolean full = true;

        for (int i = 0; i < Consts.MAX_COLS; i++) {
            full = full && (top[i] == 0);
        }

        return full;
    }

    /**
     *
     * @param myColor
     * @return: if a winning Move exists in the current state the function
     * returns the Move, else returs null
     */
    public Move getWinningMove(Color myColor) {
        boolean complete;
        int row;
        for (int col = 0; col < Consts.MAX_COLS; col++) {
            if (isLegalMove(col)) {
                row = getFirstFreeIndexOfColumn(col);

                complete = CompletesToN(myColor, 4, row, col);

                if (complete) {
                    return Move.ZeroBasedToMove(col);
                }
            }
        }
        return null;
    }

    /**
     * @return: true if completes to 3 or 4
     */
    boolean PotentialWinInNextMoveHorizontal(Color myColor, int row, int col) {
        boolean completesHor = false;
        CellState myState = CellState.translate(myColor);
        CellState oppState = CellState.translate(Color.opponent(myColor));

        //check if the position  can complete to N in a row
        int nLeft = 0, nRight = 0;
        int cLeft = col - 1;

        while (cLeft >= 0 && getCellState(cLeft, row) == myState) {
            nLeft++;
            cLeft--;
        }

        int cRight = col + 1;
        while (cRight < Consts.MAX_COLS && getCellState(cRight, row) == myState) {
            nRight++;
            cRight++;
        }

        /*
         * there is more than 3 in a row
         */
        if (nLeft + nRight + 1 > 3) {
            completesHor = true;
        } else {
            /*
             * there is exactly three in a row but there is no potential to win
             * in the next move
             */
            if (nLeft + nRight + 1 == 3) {
                if ((cRight < Consts.MAX_COLS && getCellState(cRight, row) == CellState._)
                        || (cLeft >= 0 && getCellState(cLeft, row) == CellState._)) {
                    completesHor = true;
                }
            }
        }

        return completesHor;
    }

    boolean PotentialWinInNextMoveDiagonal(Color myColor, int row, int col) {
        boolean completesDiag = false;
        CellState myState = CellState.translate(myColor);
        CellState oppState = CellState.translate(Color.opponent(myColor));

        //check if the position  can complete to N in diagonal (both sides)
        int upRight = 0;
        int downLeft = 0;
        int cUpRight = col + 1;
        int rUpRight = row + 1;

        while (rUpRight < Consts.MAX_ROWS && cUpRight < Consts.MAX_COLS && getCellState(cUpRight, rUpRight) == myState) {
            upRight++;
            cUpRight++;
            rUpRight++;
        }

        int cDownLeft = col - 1;
        int rDownLeft = row - 1;

        while (rDownLeft >= 0 && cDownLeft >= 0 && getCellState(cDownLeft, rDownLeft) == myState) {
            downLeft++;
            cDownLeft--;
            rDownLeft--;
        }

        int upLeft = 0;
        int downRight = 0;
        int cUpLeft = col - 1;
        int rUpLeft = row + 1;

        while (rUpLeft < Consts.MAX_ROWS && cUpLeft >= 0 && getCellState(cUpLeft, rUpLeft) == myState) {
            upLeft++;
            cUpLeft--;
            rUpLeft++;
        }

        int cDownRight = col + 1;
        int rDownRight = row - 1;

        while (rDownRight >= 0 && cDownRight < Consts.MAX_COLS && getCellState(cDownRight, rDownRight) == myState) {
            downRight++;
            cDownRight++;
            rDownRight--;
        }

        if (upLeft + downRight + 1 > 3 || upRight + downLeft + 1 > 3) {
            completesDiag = true;
        } else {
            if (upLeft + downRight + 1 == 3) {
                if ((rUpLeft < Consts.MAX_ROWS && cUpLeft >= 0 && (getCellState(cUpLeft, rUpLeft) != oppState))
                        || (rDownRight >= 0 && cDownRight < Consts.MAX_COLS && (getCellState(cDownRight, rDownRight) != oppState))) {
                    completesDiag = true;
                }
            }

            if (upRight + downLeft + 1 == 3) {
                if ((cUpRight < Consts.MAX_COLS && rUpRight < Consts.MAX_ROWS && (getCellState(cUpRight, rUpRight) != oppState))
                        || (cDownLeft >= 0 && rDownLeft >= 0 && (getCellState(cDownLeft, rDownLeft) != oppState))) {
                    completesDiag = true;
                }
            }
        }


        return completesDiag;
    }

    boolean PotentialWinInNextMoveVertical(Color myColor, int row, int col) {
        boolean completesVert = false;
        CellState myState = CellState.translate(myColor);

        //check if the position  can complete to N in the col    
        int counter = 1, r = row - 1;

        while (r >= 0 && getCellState(col, r) == myState) {
            counter++;
            r--;
        }

        if (counter > 3) {
            completesVert = true;
        } else {
            if (counter == 3) {
                if (row == Consts.MAX_ROWS - 1) {
                    completesVert = false;
                } else {
                    completesVert = true;
                }
            }
        }

        return completesVert;
    }

    /**
     *
     * @param myColor
     * @param row
     * @param col
     * @return true if the cell at row,col completes to a sequence of 3 (or
     * more) and is not blocked (could potentially be completed to 4)
     */
    boolean PotentialWinInNextMove(Color myColor, int row, int col) {
        return (PotentialWinInNextMoveDiagonal(myColor, row, col)
                || PotentialWinInNextMoveHorizontal(myColor, row, col)
                || PotentialWinInNextMoveVertical(myColor, row, col));
    }

    /**
     *
     * @param myColor
     * @param n
     * @param row
     * @param col
     * @return: returns true if there will be n in a row if a disk of the color
     * myColor will be put in the cell (row, col)
     */
    public boolean CompletesToN(Color myColor, int n, int row, int col) {
        boolean completesRow = false;
        boolean completesCol = false;
        boolean completesDiag = false;
        CellState myState = CellState.translate(myColor);

        //check if the position  can complete to N in a row
        int nLeft = 0, nRight = 0;
        int c = col - 1;

        while (c >= 0 && getCellState(c, row) == myState) {
            nLeft++;
            c--;
        }

        c = col + 1;
        while (c < Consts.MAX_COLS && getCellState(c, row) == myState) {
            nRight++;
            c++;
        }

        if (nLeft + nRight + 1 >= n) {
            completesRow = true;
        }

        //check if the position  can complete to N in the col    
        int counter = 1, r = row - 1;

        while (r >= 0 && getCellState(col, r) == myState) {
            counter++;
            r--;
        }

        if (counter >= n) {
            completesCol = true;
        }

        //check if the position  can complete to N in diagonal (both sides)
        int upRight = 0;
        int downLeft = 0;
        c = col + 1;
        r = row + 1;

        while (r < Consts.MAX_ROWS && c < Consts.MAX_COLS && getCellState(c, r) == myState) {
            upRight++;
            c++;
            r++;
        }

        c = col - 1;
        r = row - 1;

        while (r >= 0 && c >= 0 && getCellState(c, r) == myState) {
            downLeft++;
            c--;
            r--;
        }

        int upLeft = 0;
        int downRight = 0;
        c = col - 1;
        r = row + 1;

        while (r < Consts.MAX_ROWS && c >= 0 && getCellState(c, r) == myState) {
            upLeft++;
            c--;
            r++;
        }

        c = col + 1;
        r = row - 1;

        while (r >= 0 && c < Consts.MAX_COLS && getCellState(c, r) == myState) {
            downRight++;
            c++;
            r--;
        }

        if (upLeft + downRight + 1 >= n || upRight + downLeft + 1 >= n) {
            completesDiag = true;
        }

        return completesRow || completesCol || completesDiag;
    }

    int getSequenceLengthInDirection(int r, int c, int dr, int dc, CellState cellState) {
        if (grid[r][c] != cellState) {
            return 0;
        }

        int col = c, row = r;
        int length;
        for (length = 1;; length++) {
            row += dr;
            col += dc;
            if (row < 0 || row >= Consts.MAX_ROWS) {
                break;
            }
            if (col < 0 || col >= Consts.MAX_COLS) {
                break;
            }
            if (grid[row][col] != cellState) {
                break;
            }
        }

        return length;
    }
}
