package fiarautoplayer;

/**
 * Enum of possible states for a cell on the board
 * @author sali
 */

/* each cell can be in one of three states: RED disk, BLACK disk or no disk ( _ )*/
public enum CellState {
    _,
    RED,
    BLACK;

    /* the function receives a color and returns the matching CellState */
    static CellState translate(Color color) {
            if (Color.BLACK == color)
            return CellState.BLACK;
            else 
                return CellState.RED;
        }
    
    
}

