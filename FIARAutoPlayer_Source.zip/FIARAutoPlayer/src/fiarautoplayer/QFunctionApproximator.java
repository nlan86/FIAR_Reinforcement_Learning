package fiarautoplayer;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

/**
 * Representation of Q Function approximator for player
 *
 * Holds a linear function approximator for each move(column) and provides
 * functions for updating weights and evaluation of Q function
 *
 * @author sali
 */
public class QFunctionApproximator {

    private LinearFunctionApproximator[] moveQApproximators;

    /**
     *
     * Construct approximators with default params
     *
     * @param nFeatures
     * @param nActions
     */
    public QFunctionApproximator(int nFeatures, int nActions) {
        moveQApproximators = new LinearFunctionApproximator[nActions];
        for (int i = 0; i < nActions; i++) {
            moveQApproximators[i] = new LinearFunctionApproximator(nFeatures);
        }
    }

    /**
     *
     * Construct approximators with saved params from xml file
     *
     * @param QFunctionApproximatorElem
     */
    public QFunctionApproximator(Element QFunctionApproximatorElem) {

        int numOfActions = Integer.parseInt(QFunctionApproximatorElem.getAttribute(Consts.XML_TAG_NUM_OF_ACTIONS));
        moveQApproximators = new LinearFunctionApproximator[numOfActions];
        NodeList ApproximatorNodeLst = QFunctionApproximatorElem.getElementsByTagName(Consts.XML_ActionQApprox);

        for (int j = 0; j < numOfActions; j++) {
            Element ActionQApproxElement = (Element) ApproximatorNodeLst.item(j); //get "ActionQApproximator" node
            NodeList WeightsNodeLst = ActionQApproxElement.getElementsByTagName(Consts.XML_TAG_WEIGHT); //get list of "<weight>" values

            int numOfFeatures = Integer.parseInt(ActionQApproxElement.getAttribute(Consts.XML_TAG_NUM_OF_FEATURES));

            LinearFunctionApproximator newFuncApprox = new LinearFunctionApproximator(numOfFeatures);

            for (int i = 0; i < WeightsNodeLst.getLength(); i++) { //collect weights
                String val = WeightsNodeLst.item(i).getChildNodes().item(0).getNodeValue();
                newFuncApprox.UpdateWeight(i, Double.parseDouble(val));
            }

            moveQApproximators[j] = newFuncApprox;
        }
    }

    /**
     * Updates specific weight in specific move (column action)
     * 
     * @param iAction
     * @param iFeature
     * @param newWeight
     */
    public void UpdateWeight(int iAction, int iFeature, double newWeight) {
        moveQApproximators[iAction].UpdateWeight(iFeature, newWeight);
    }

    
    /**
     *
     * @param iAction
     * @param iFeature
     * @return Weight number iFeature of iAction move
     */
    public double GetWeight(int iAction, int iFeature) {
        return moveQApproximators[iAction].GetWeight(iFeature);
    }

    /**
     * 
     * @param iAction
     * @param features
     * @return Sigma of weight*feature val for specific action
     */
    public double Evaluate(int iAction, int[] features) {
        return moveQApproximators[iAction].Evaluate(features);
    }

    /**
     *
     * @return New xml element '<QLinearApproximation>' with current function approximators as subfields
     * @throws Exception
     */
    public Element SerializeToXmlElem(String elementName) throws Exception {

        int numOfActions = moveQApproximators.length;
        int numOfFeatures = moveQApproximators[0].weights.length;

        //create new xml document
        DocumentBuilderFactory documentBuilderFactory =
                DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder =
                documentBuilderFactory.newDocumentBuilder();
        Document document = documentBuilder.newDocument();

        //create approximator tree
        Element QFunctionApproximatorElem = document.createElement(elementName);
        QFunctionApproximatorElem.setAttribute(Consts.XML_TAG_NUM_OF_ACTIONS, Integer.toString(numOfActions));
        document.appendChild(QFunctionApproximatorElem);

        //run over all actions
        for (int j = 0; j < numOfActions; j++) {
            Element newActionApprox = document.createElement(Consts.XML_ActionQApprox);
            newActionApprox.setAttribute(Consts.XML_TAG_NUM_OF_FEATURES, Integer.toString(numOfFeatures));

            //add weights for each action function
            for (int i = 0; i < numOfFeatures; i++) { //add weights to current action 
                Element newWeight = document.createElement(Consts.XML_TAG_WEIGHT);
                newWeight.setAttribute("number", Integer.toString(i));
                newWeight.setTextContent(Double.toString(moveQApproximators[j].weights[i]));
                newActionApprox.appendChild(newWeight);
            }

            //save action function into main approximator
            QFunctionApproximatorElem.appendChild(newActionApprox);
        }

        return QFunctionApproximatorElem;
    }
    
    /**
     * 
     */
    public void normalizeWeights() {
        for (int i=0;i<Consts.MAX_COLS;i++){
            double  min = Double.POSITIVE_INFINITY;
            double  max = Double.NEGATIVE_INFINITY;
            for (int j=0;j<FIARFeatureExtractor.nFeatures;j++){
                double  weight = this.GetWeight(i, j);
                if (max == Double.POSITIVE_INFINITY ||weight - max> Consts.PERCISION)
                    max = weight;
                if (min == Double.NEGATIVE_INFINITY ||Consts.PERCISION < min - weight)
                    min = weight;
            }
            
            //long  margin = StrictMath.round(StrictMath.abs(max - min)) ;
            Double margin = StrictMath.abs(max - min);
            
            if (margin != 0)
            {
                for (int j=0;j<FIARFeatureExtractor.nFeatures;j++){
                    double  weight = this.GetWeight(i, j);
                    this.UpdateWeight(i, j, weight/margin);
                }
            }
        }
    }
}
