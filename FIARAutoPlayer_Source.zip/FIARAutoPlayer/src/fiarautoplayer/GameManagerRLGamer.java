
package fiarautoplayer;

import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import player.gamer.statemachine.sadna.FourInARow;

/**
 * Adapter class between the game manager infrastructure and our internal
 * framework reports game events to a PlayEventsListener. Uses given
 * learnerState
 *
 * @author sali
 */
public class GameManagerRLGamer extends RLGamer implements FourInARow {

    private static PlayEventsListener peListener = null;
    private static FIARLearnerState PlayConfig = null;
    
    private boolean findOutFirstOrSecond = true;
    /**
     * Sets global learned state for the player playing in the GameManager infra
     *
     * @param learnerState
     */
    public static void setLearnerState(FIARLearnerState learnerState) {
        GameManagerRLGamer.PlayConfig = learnerState;
    }

    /**
     * Sets global game events listener for the player playing in the
     * GameManager infra
     *
     * @param sListener
     */
    public static void setGameEventsListener(PlayEventsListener sListener) {
        GameManagerRLGamer.peListener = sListener;
    }

    /**
     * Used by GameManager infra to construct a gamer that uses an epsilon
     * greedy Q policy from given global learnerState
     *
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     */
    public GameManagerRLGamer() throws ParserConfigurationException, SAXException, IOException {
        super(Color.BLACK, new GreedyQPolicy(PlayConfig.GetFirstQLinearApproximation(), PlayConfig.getEpsilon(),false));
    }
    static FIARState myState = new FIARState();

    /**
     *
     * @return curren board state
     */
    public static FIARState getBoardState() {
        return myState;
    }

    /**
     * used by GameManager infra to report a game over, positive reward means
     * victory and zero a loss
     *
     * @param reward
     */
    @Override
    public void fourEnd(int reward) {
        Color winner;
        if (reward == 0) {
            winner = Color.opponent(myColor);
            reward = -Consts.WIN_REWARD;
        } else if (reward > 0) {
            winner = myColor;
            reward = Consts.WIN_REWARD;
        } else {
            winner = myColor;
            reward = 0;
        }

        try {
            endGame(myState, reward);
            if (peListener != null) {
                peListener.OnGameOver(winner, myState);
            }
        } catch (Exception ex) {
            Logger.getLogger(GameManagerRLGamer.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    /**
     * Used by GameManager infra to report a move and to get our player next move. 
     * We update the board state according to the move. Then passes the info to the underlying RLGamer
     *
     * @param moved  what the other player played 
     * @param options what are my options (not sorted) if moved is empty i amd the first player
     * @param timeLimit
     * @return
     */
    @Override //play
    public int fourMove(List<Integer> moved, List<Integer> options, long timeLimit) {
        Move myNextMove = null;;

        // if moved is empty then this player is the first, otherwise update our state with the opponent move
        // and inform listener the board changed
        if (!moved.isEmpty()) {
            if (findOutFirstOrSecond){
                setAlgorithm(new GreedyQPolicy(PlayConfig.GetSecondQLinearApproximation(),PlayConfig.getEpsilon(),true));
                findOutFirstOrSecond = false;
            }
            myState.putAt(moved.get(0) - 1, Color.opponent(myColor)); // add opponents last move to the current board
            if (peListener != null) {
                peListener.stateChange(myState);
            }
        }else{
            if (findOutFirstOrSecond){
                setAlgorithm(new GreedyQPolicy(PlayConfig.GetFirstQLinearApproximation(),PlayConfig.getEpsilon(),true));
                findOutFirstOrSecond = false;
            }
        }
        try {
            myNextMove = this.play(myState);
        } catch (Exception ex) {
            Logger.getLogger(GameManagerRLGamer.class.getName()).log(Level.SEVERE, null, ex);
        }

        if (peListener != null) {
            peListener.stateChange(myState);
        }
        return options.indexOf(myNextMove.getcolNumOneBased());

    }

    /**
     * Used by GameManager infra to indicate a start of game
     * @param role this players role (i.e red/black)
     */
    @Override
    public void fourStart(String role) {
        findOutFirstOrSecond = true;
        this.newGame(Color.translate(role));

        myState.reset();
        if (peListener != null) {
            peListener.newGame(myColor);
            peListener.stateChange(myState);
        }

    }
}
