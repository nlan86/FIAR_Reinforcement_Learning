package fiarautoplayer;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * Represents the state of the learning process It holds the values of the
 * learning parameters, number of simulated games used in the learning process
 * and the learned weights of the function approximators
 */
public class FIARLearnerState {

    //default string used to create xml object from scratch
    private static String defaultEmptyXmlString = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>"
            + "<RLGamerData>"
            + "<GlobalParameters>"
            + "<Gamma>0.5</Gamma>"
            + "<Epsilon>0.5</Epsilon>"
            + "<GamesPlayed>0</GamesPlayed>"
            + "</GlobalParameters>"
            + "<" + Consts.XML_FirstQLinearApprox + "  numOfActions = \"" + Consts.MAX_COLS + "\">"
            + "</" + Consts.XML_FirstQLinearApprox + ">"
            + "<" + Consts.XML_SecondQLinearApprox + " numOfActions = \"" + Consts.MAX_COLS + "\">"
            + "</" + Consts.XML_SecondQLinearApprox + ">"
            + "</RLGamerData>";
    Document xmlDoc; //representor of whole xml object
    QFunctionApproximator first_qFuncApproximator; //representation of qfunc approximator according to xml (first player)
    QFunctionApproximator second_qFuncApproximator; //representation of qfunc approximator according to xml (second player)
    private double epsilon;

    /**
     * Empty constructor for FIARLearnerState Creates default xml object with
     * default Gamma, Epsilon and empty QFunction Approx according to constants
     * and conventions
     *
     * @throws SAXException
     * @throws ParserConfigurationException
     * @throws IOException
     */
    public FIARLearnerState() throws SAXException, ParserConfigurationException, IOException {
        // Build template xmlDoc
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        InputSource is = new InputSource();
        is.setCharacterStream(new StringReader(defaultEmptyXmlString));

        xmlDoc = db.parse(is);

        //set defaults
        gamesPlayed = Consts.DEFAULT_GAMES_PLAYED;
        gamma = Consts.DEFAULT_GAMMA;
        epsilon = Consts.DEFAULT_EPSILON;
        first_qFuncApproximator = new QFunctionApproximator(FIARFeatureExtractor.nFeatures, Consts.MAX_COLS);
        second_qFuncApproximator = new QFunctionApproximator(FIARFeatureExtractor.nFeatures, Consts.MAX_COLS);

    }

    /**
     *
     * @return number of games played
     */
    public int getGamesPlayed() {
        return gamesPlayed;
    }

    /**
     *
     * @return current Gamma value
     */
    public double getGamma() {
        return gamma;
    }
    double gamma;
    int gamesPlayed;

    /**
     * Creates new RLConfiguration instance according to existing XML file.
     *
     * File is assumed correct and containing pre-defined fields as specified in
     * design specification document. Retrieves existing Q Function Approximator
     * and sets member accordingly.
     *
     * @param XmlConfigFilename - path to existing xml file
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     */
    public FIARLearnerState(String XmlConfigFilename) throws ParserConfigurationException, SAXException, IOException {
        File xmlFile = new File(XmlConfigFilename);

        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance(); //open xml file
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        xmlDoc = dBuilder.parse(xmlFile);
        xmlDoc.getDocumentElement().normalize();

        NodeList globalParamsNList = xmlDoc.getElementsByTagName(Consts.XML_GLOBAL_PARAMS); //get params object from xml
        Node globalParamsNode = globalParamsNList.item(0);
        Element globalElem = (Element) globalParamsNode;
        NodeList nList = globalElem.getElementsByTagName(Consts.XML_GLOBAL_PARAMS_GAMMA).item(0).getChildNodes();
        Node nTemp = (Node) nList.item(0);
        gamma = Double.parseDouble(nTemp.getNodeValue());
        nList = globalElem.getElementsByTagName(Consts.XML_GLOBAL_PARAMS_GAMESPLAYED).item(0).getChildNodes();
        nTemp = (Node) nList.item(0);
        gamesPlayed = Integer.parseInt(nTemp.getNodeValue());
        nList = globalElem.getElementsByTagName(Consts.XML_GLOBAL_PARAMS_EPSILON).item(0).getChildNodes();
        nTemp = (Node) nList.item(0);
        epsilon = Double.parseDouble(nTemp.getNodeValue());

        first_qFuncApproximator = new QFunctionApproximator((Element) xmlDoc.getElementsByTagName(Consts.XML_FirstQLinearApprox).item(0)); //get q function approximator from xml
        second_qFuncApproximator = new QFunctionApproximator((Element) xmlDoc.getElementsByTagName(Consts.XML_SecondQLinearApprox).item(0)); //get q function approximator from xml
    }

    public FIARLearnerState(Boolean createFromString, String xmlString) {
        if (createFromString) {
            try {
                try {
                    xmlDoc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new ByteArrayInputStream(xmlString.getBytes()));
                    xmlDoc.getDocumentElement().normalize();

                } catch (SAXException ex) {
                    Logger.getLogger(FIARLearnerState.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(FIARLearnerState.class.getName()).log(Level.SEVERE, null, ex);
                }
            } catch (ParserConfigurationException ex) {
                Logger.getLogger(FIARLearnerState.class.getName()).log(Level.SEVERE, null, ex);
            }

            NodeList globalParamsNList = xmlDoc.getElementsByTagName(Consts.XML_GLOBAL_PARAMS); //get params object from xml
            Node globalParamsNode = globalParamsNList.item(0);
            Element globalElem = (Element) globalParamsNode;
            NodeList nList = globalElem.getElementsByTagName(Consts.XML_GLOBAL_PARAMS_GAMMA).item(0).getChildNodes();
            Node nTemp = (Node) nList.item(0);
            gamma = Float.parseFloat(nTemp.getNodeValue());
            nList = globalElem.getElementsByTagName(Consts.XML_GLOBAL_PARAMS_GAMESPLAYED).item(0).getChildNodes();
            nTemp = (Node) nList.item(0);
            gamesPlayed = Integer.parseInt(nTemp.getNodeValue());
            nList = globalElem.getElementsByTagName(Consts.XML_GLOBAL_PARAMS_EPSILON).item(0).getChildNodes();
            nTemp = (Node) nList.item(0);
            epsilon = Float.parseFloat(nTemp.getNodeValue());


            first_qFuncApproximator = new QFunctionApproximator((Element) xmlDoc.getElementsByTagName(Consts.XML_FirstQLinearApprox).item(0)); //get q function approximator from xml
            second_qFuncApproximator = new QFunctionApproximator((Element) xmlDoc.getElementsByTagName(Consts.XML_SecondQLinearApprox).item(0)); //get q function approximator from xml


        }
    }

    /**
     * Gets first player QFunctionLinearApproximator node from XML file
     *
     * @return first player QFunctionLinearApproximator
     */
    public QFunctionApproximator GetFirstQLinearApproximation() {
        return first_qFuncApproximator;
    }

    /**
     * Gets second player QFunctionLinearApproximator node from XML file
     *
     * @return second player QFunctionLinearApproximator
     */
    public QFunctionApproximator GetSecondQLinearApproximation() {
        return second_qFuncApproximator;
    }

    /**
     *
     * Saves current learning configuration to given XML file
     *
     * @param filename path to save file
     * @throws TransformerConfigurationException
     * @throws TransformerException
     * @throws IOException
     * @throws Exception
     */
    public void SaveToXmlFile(String filename) throws TransformerConfigurationException, TransformerException, IOException, Exception {

        File outFile = new File(filename); //creates new file if given path does not exist
        if (!outFile.exists()) {
            outFile.createNewFile();
        }

        this.setPlayerQApproxXMLElem(first_qFuncApproximator.SerializeToXmlElem(Consts.XML_FirstQLinearApprox), Consts.XML_FirstQLinearApprox); //convert qLinearApprox to xml object
        this.setPlayerQApproxXMLElem(second_qFuncApproximator.SerializeToXmlElem(Consts.XML_SecondQLinearApprox), Consts.XML_SecondQLinearApprox); //convert qLinearApprox to xml object

        NodeList globalParamsNList = xmlDoc.getElementsByTagName(Consts.XML_GLOBAL_PARAMS);
        Node globalParamsNode = globalParamsNList.item(0);

        Element globalElem = (Element) globalParamsNode;

        //set values in still memory-held xml object
        NodeList nList = globalElem.getElementsByTagName(Consts.XML_GLOBAL_PARAMS_GAMMA).item(0).getChildNodes();
        Node nTemp = (Node) nList.item(0);
        nTemp.setTextContent(String.valueOf(gamma));

        nList = globalElem.getElementsByTagName(Consts.XML_GLOBAL_PARAMS_GAMESPLAYED).item(0).getChildNodes();
        nTemp = (Node) nList.item(0);
        nTemp.setTextContent(String.valueOf(gamesPlayed));

        nList = globalElem.getElementsByTagName(Consts.XML_GLOBAL_PARAMS_EPSILON).item(0).getChildNodes();
        nTemp = (Node) nList.item(0);
        nTemp.setTextContent(String.valueOf(epsilon));

        //write object to actual file
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        DOMSource source = new DOMSource(xmlDoc);
        StreamResult result = new StreamResult(new FileWriter(outFile));
        transformer.transform(source, result);

        result.getWriter().close();
    }

    private void setPlayerQApproxXMLElem(Element NewQLinearApproximator, String nodeName) {
        Node newImportedNode = xmlDoc.importNode(NewQLinearApproximator, true);

        NodeList qFuncApproxNList = xmlDoc.getElementsByTagName(nodeName);
        Node qFuncApproxNode = qFuncApproxNList.item(0);
        Element parentElement = (Element) qFuncApproxNode.getParentNode();
        parentElement.insertBefore(newImportedNode, qFuncApproxNode);
        qFuncApproxNode.getParentNode().removeChild(qFuncApproxNode);
        parentElement.normalize();
    }

    /**
     * Replaces current XML document's Q function linear approximator with new
     * one. New approximator element is received from
     * QFunctionApproximator.DumpWeights()
     *
     * @param NewQLinearApproximator
     */
    public void setFirstPlayerQApproxXMLElem(Element NewQLinearApproximator) {
        setPlayerQApproxXMLElem(NewQLinearApproximator, Consts.XML_FirstQLinearApprox);
    }

    /**
     * Replaces current XML document's Q function linear approximator with new
     * one. New approximator element is received from
     * QFunctionApproximator.DumpWeights()
     *
     * @param NewQLinearApproximator
     */
    public void setSecondPlayerQApproxXMLElem(Element NewQLinearApproximator) {
        setPlayerQApproxXMLElem(NewQLinearApproximator, Consts.XML_SecondQLinearApprox);
    }

    /**
     * Set new number of games played so far
     *
     * @param GamesPlayed
     */
    public void setGamesPlayed(int GamesPlayed) {
        this.gamesPlayed = GamesPlayed;
    }

    /**
     * Set new Gamma value
     *
     * @param Gamma
     */
    public void setGamma(double Gamma) {
        this.gamma = Gamma;
    }

    /**
     *
     */
    public void incGamesPlayed() {
        this.gamesPlayed++;
    }

    /**
     *
     * @param f
     */
    public void setEpsilon(double f) {
        this.epsilon = f;
    }

    /**
     *
     * @return
     */
    public double getEpsilon() {
        return this.epsilon;
    }
}
