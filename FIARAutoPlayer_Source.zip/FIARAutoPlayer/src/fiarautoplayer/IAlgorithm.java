package fiarautoplayer;

/**
 * Basic interface for a playing/learning algorithm
 *
 * @author sali
 */
public interface IAlgorithm {
        void initState();
        Move returnNextMove(FIARState currentState, Color myColor) throws Exception;
        void reportLoss(FIARState currentState, Color loserColor, int reward) throws Exception;
        void reportWin(FIARState currentState, Color winnerColor, int reward) throws Exception;
}
