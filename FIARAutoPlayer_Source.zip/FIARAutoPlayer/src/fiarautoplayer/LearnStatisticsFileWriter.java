package fiarautoplayer;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Writes learning process statistics to a csv log with the following columns:
 *
 * Game num – game number in learn sequence Winners 
 * Color – color of the winner, indicates first (RED) or second player (BLACK)
 * Num of turns – Number of plys  the game took 
 * Game sequence – space separated integer list representing the  moves sequence 
 * maxUpdateDelta – the maximal Q error of the sarsa update rule during the game
 *
 * @author sali
 */
public class LearnStatisticsFileWriter implements LearnStatisticsListener {

    FileWriter fWriter;
    int nFeatures;
    int nActions;

    /**
     *
     * @param fileName: the path to the file where we will write information
     * regarding the games played during the training process
     * @param nFeatures: num of features extracted from the board game
     * @param nActions: num of possible actions in the game
     * @throws IOException
     */
    public LearnStatisticsFileWriter(String fileName, int nFeatures, int nActions) throws IOException {
        this.nFeatures = nFeatures;
        this.nActions = nActions;

        File file = new File(fileName);

        fWriter = new FileWriter(file);
        fWriter.write(fileName);

        writeFileHeader(fWriter, nFeatures, nActions);
    }

    /**
     *
     * @param fileName
     * @throws IOException
     */
    public LearnStatisticsFileWriter(String fileName) throws IOException {
        this(fileName, FIARFeatureExtractor.nFeatures, Consts.MAX_COLS);
    }

    /**
     * the function writes to a file information about the training session,
     * such as: winner of each games, num of turns it took to win etc.
     *
     * @param qFunction
     * @param winner: the color of the winner of the game
     * @param nTurns: num of turns it took to win the game
     * @param conversionMeasure
     * @param nGamesPlayed: num of games played in the current session
     * @param gameSequence: the list of actions chosen in the current game
     */
    @Override
    public void onGameOver(Color winner, int nTurns, int nGamesPlayed, List<Integer> gameSequence, double maxUpdateDeltaInGame) {
        try {
            fWriter.append(Integer.toString(nGamesPlayed));
            fWriter.append(",");
            if (winner == null) {
                fWriter.append("tie");
            } else {
                fWriter.append(winner.toString());
            }
            fWriter.append(",");
            fWriter.append(Integer.toString(nTurns));
            fWriter.append(",");

            /*
             * for (int j = 0; j < nActions; j++) { for (int i = 0; i <
             * nFeatures; i++) {
             * fWriter.append(Double.toString(qFunction.GetWeight(j, i)));
             * fWriter.append(","); } }
             */

            for (Integer move : gameSequence) {
                fWriter.append(move.toString() + " ");
            }
            fWriter.append(",");
            fWriter.append(Double.toString(maxUpdateDeltaInGame));

            fWriter.append('\n');

        } catch (IOException ex) {
            Logger.getLogger(LearnStatisticsFileWriter.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    /**
     * this function closes the file
     */
    public void finish() {
        try {
            fWriter.close();
        } catch (IOException ex) {
            Logger.getLogger(LearnStatisticsFileWriter.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /*
     * this function writes the header of the file which includen the number of
     * featured extracted from the game and the number of actions
     */
    private void writeFileHeader(FileWriter fWriter, int nFeatures, int nActions) {
        try {

            fWriter.append("Game num");
            fWriter.append(",");
            fWriter.append("Winners Color");
            fWriter.append(",");
            fWriter.append("Num of turns");
            fWriter.append(",");
            /*
             * for (int j = 0; j < nActions; j++) { for (int i = 0; i <
             * nFeatures; i++) { fWriter.append("Q" + j + "W" + i);
             * fWriter.append(","); } }
             */
            fWriter.append("GameSequence");
            fWriter.append(",");
            fWriter.append("maxUpdateDelta");

            fWriter.append('\n');
        } catch (IOException ex) {
            Logger.getLogger(LearnStatisticsFileWriter.class.getName()).log(Level.SEVERE, null, ex);
        }


    }
}
