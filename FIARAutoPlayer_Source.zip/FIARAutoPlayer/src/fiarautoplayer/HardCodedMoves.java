package fiarautoplayer;

import java.util.Random;

/**
 *This calss encapsulates the hard coded moves used in the training process
 * @author sali
 */
public class HardCodedMoves {
    Random rand = new Random();
    /**
     *
     * @param state: the current state of the game
     * @param myColor: the players color
     * @return: next hard coded move. null else.
     */
    public Move getMove(FIARState state, Color myColor) {

        /*
         * if exisits, returns a winning move
         */
        if (state.isEmpty()) {
            // if we start want to randomly begin so we can learn more of the game tree
            return Move.ZeroBasedToMove(rand.nextInt(Consts.MAX_COLS));
        } else {
            /* if there is a winning move we take it*/
             return state.getWinningMove(myColor);
        }
    }
}
