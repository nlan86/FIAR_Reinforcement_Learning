package fiarautoplayer;

/**
 *Class that compares two player configurations by running them against eachother
 * @author Shanee Lavi
 */
public class TestManager {

    FIARLearnerState learnerStateBlack;
    FIARLearnerState learnerStateRed;
    FIARState state;
    Color lastWinner;
    int numTurns;

    /**
     *
     * @return: the black players FIARLearnerState
     */
    public FIARLearnerState getLearnerStateBlack() {
        return learnerStateBlack;
    }

    /**
     *
     * @return: the red players FIARLearnerState
     */
    public FIARLearnerState getLearnerStateRed() {
        return learnerStateRed;
    }

    /**
     * creates a new Testmanager
     *
     * @param learnerStateBlack
     * @param learnerStateRed
     */
    public TestManager(FIARLearnerState learnerStateBlack, FIARLearnerState learnerStateRed) {
        this.learnerStateBlack = learnerStateBlack;
        this.learnerStateRed = learnerStateRed;

        state = new FIARState();
    }

    /*
     * switches the current player to be the other player
     */
    private static RLGamer toggleCurrent(RLGamer current, RLGamer first, RLGamer second) {
        return (current == first ? second : first);
    }

    /*
     * the function runs a single game in a test session
     */
    private void runSingleGame(RLGamer first, RLGamer second) throws Exception {

        numTurns = 0;
        state.reset();
        RLGamer current = first;
        Move lastMove = current.play(state);

        // Continue run until last player didn't win or tied with lastMove
        while (!state.hasWonAt(current.getMyColor(), lastMove) && !state.isFull()) {
            current = toggleCurrent(current, first, second);
            lastMove = current.play(state);
            numTurns++;
        }

        // check if ended with win or tie
        if (state.hasWonAt(current.getMyColor(), lastMove)) {
            lastWinner = current.getMyColor();
        } else {
            lastWinner = null;
        }
    }

    /**
     * the function runs a testing session between two players. at the end of
     * each game in the session it updates the listener (by calling its function
     * onGameOver)
     *
     * @param nGame: num of games to be played
     * @param sListener
     * @throws Exception
     */
    public void runTestingSequence(int nGame, TestStatisticsListener sListener) throws Exception {
        int nGames = nGame;
        int played = 0;

        RLGamer redFirstGamer = new RLGamer(Color.RED, new GreedyQPolicy(learnerStateRed.GetFirstQLinearApproximation(), learnerStateRed.getEpsilon(), true));
        RLGamer blackSecondGamer = new RLGamer(Color.BLACK, new GreedyQPolicy(learnerStateBlack.GetSecondQLinearApproximation(), learnerStateBlack.getEpsilon(), true));
        RLGamer redSecondGamer = new RLGamer(Color.RED, new GreedyQPolicy(learnerStateRed.GetSecondQLinearApproximation(), learnerStateRed.getEpsilon(), true));
        RLGamer blacFirstkGamer = new RLGamer(Color.BLACK, new GreedyQPolicy(learnerStateBlack.GetFirstQLinearApproximation(), learnerStateBlack.getEpsilon(), true));
        // each player will have an equal number of games as the first player
        while (played < nGames) {
            if (played < nGames / 2) {
                // red first

                runSingleGame(redFirstGamer, blackSecondGamer);
                sListener.onGameOver(Color.RED, lastWinner);
            } else {
                // black first

                runSingleGame(blacFirstkGamer, redSecondGamer);
                sListener.onGameOver(Color.BLACK, lastWinner);
            }

            played++;
        }
    }
}
