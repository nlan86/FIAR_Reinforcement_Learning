/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fiarautoplayer;

/**
 * Main class in charge of extracting all features from board
 *
 * @author sali
 */
public class FIARFeatureExtractor implements IFeatureExtractor {

    /**
     *
     */
    public static final int nFeatures = Consts.MAX_COLS * Consts.MAX_ROWS + 3 * 2 * Consts.MAX_COLS
            + //            2 * 3 /*sequence histograms*/
            //             + 3/*<-parity of unisen rows+legalmoves*/
            2 // zugzwang
            ;

    /**
     * Extracts 3 types of features: 1. raw board state 2. for each column for
     * each player: completion to 3 for top used cell, completetion to 3,4 for
     * top unused cell. 3. zugzwangz feature - checks for if player has even
     * threat and all rows are even
     *
     * @param state: current borad state
     * @param myColor: the color fo the player
     * @return: the function returns a feature vector representing the current
     * state of the game
     * @throws Exception
     */
    @Override
    public int[] extractFeatures(FIARState state, Color myColor) {
        int[] features = new int[nFeatures];
        CellState myState = CellState.translate(myColor);

        Integer f = 0;

        /*
         * completes the features of type 1
         */
        for (int c = 0; c < Consts.MAX_COLS; c++) {
            for (int r = 0; r < Consts.MAX_ROWS; r++) {
                if (state.getCellState(c, r) == myState) {
                    features[f++] = 1;
                } else if (state.getCellState(c, r) == CellState._) {
                    features[f++] = 0;
                } else {
                    features[f++] = -1;
                }
            }
        }

        // type 2 features
        f = extractType2Features(state, features, f, myColor, 1);
        f = extractType2Features(state, features, f, Color.opponent(myColor), -1);
        // f = extractSequenceLengthHistogramFeatures(state, features, f, myColor, 1);
        //f = extractSequenceLengthHistogramFeatures(state, features, f, Color.opponent(myColor), -1);

        // zugzwang
        f = extractZugzwangFeature(state, features, f, myColor, 1);
        f = extractZugzwangFeature(state, features, f, Color.opponent(myColor), -1);


        // parity of num of legal columns
//        if (state.getLegalMoves().length % 2 == 0) {
//            features[f++] = 1;
//            features[f++] = 0;
//        } else {
//            features[f++] = 0;
//            features[f++] = 1;
//        }
//        // do all columns contain even rows
//        boolean allEven = true;
//        for(int i =0;i<Consts.MAX_COLS;i++){
//            allEven = allEven && state.getFirstFreeIndexOfColumn(i) % 2 == 0;
//        }
//        features[f++] = (allEven?1:0);

        //   f = extractType3Features(state, features, f, myColor);


        return features;
    }

    private int extractType2Features(FIARState state, int[] features, Integer f, Color myColor, int val) {

        boolean topFullCell3, firstFreeCell3, firstFreeCell4;

        for (int c = 0; c < Consts.MAX_COLS; c++) {

            int topCol = state.getFirstFreeIndexOfColumn(c);
            topFullCell3 = false;
            firstFreeCell3 = false;
            firstFreeCell4 = false;


            // the is no more room in this column so all features matching this col will get 0
            if (topCol != Consts.MAX_ROWS) {
                if (topCol != 0) {

                    topFullCell3 = state.PotentialWinInNextMove(myColor, topCol - 1, c);
                }
                firstFreeCell3 = state.PotentialWinInNextMove(myColor, topCol, c);
                firstFreeCell4 = state.CompletesToN(myColor, 4, topCol, c);

            } else {
                topFullCell3 = state.PotentialWinInNextMove(myColor, topCol - 1, c);
            }

            features[f++] = (topFullCell3 ? val : 0);;
            features[f++] = (firstFreeCell3 ? val : 0);
            features[f++] = (firstFreeCell4 ? val : 0);
        }

        return f;
    }

    /*
     * private int extractType2Features(FIARState state, int[] features, Integer
     * f, Color myColor, int val) { for (int c = 0; c < Consts.MAX_COLS; c++) {
     *
     * int topCol = state.getFirstFreeIndexOfColumn(c);
     *
     * // the is no more room in this column so all features matching this col
     * will get 0 if (topCol == Consts.MAX_ROWS) { features[f++] = 0;
     * features[f++] = 0; features[f++] = 0; features[f++] = 0; } else { //firts
     * row above //boolean completes3 = state.CompletesToN(myColor, 3, topCol,
     * c); boolean completes3 = state.PotentialWinInNextMove(myColor, topCol,
     * c); boolean completes4 = state.CompletesToN(myColor, 4, topCol, c);
     *
     * features[f++] = (completes3 ? val : 0); features[f++] = (completes4 ? val
     * : 0); // second row above if (topCol + 1 == Consts.MAX_ROWS) {
     * features[f++] = 0; features[f++] = 0; } else { //completes3 =
     * state.CompletesToN(myColor, 3, topCol + 1, c); completes3 =
     * state.PotentialWinInNextMove(myColor, topCol + 1, c); completes4 =
     * state.CompletesToN(myColor, 4, topCol + 1, c); features[f++] =
     * (completes3 ? val : 0); features[f++] = (completes4 ? val : 0); } } }
     *
     * return f;
    }
     */
    /*
     * private int extractType3Features(FIARState state, int[] features, Integer
     * f, Color myColor) { int myNumCompletes4 = 0; int opponentNumCompletes4 =
     * 0; Color opponentColor = Color.opponent(myColor);
     *
     * int topRow;
     *
     * // count the num of columns in the board where the payer and his //
     * opponent can complete to 4
     *
     * for (int c = 0; c < Consts.MAX_COLS; c++) { topRow =
     * state.getFirstFreeIndexOfColumn(c);
     *
     * if (topRow == Consts.MAX_ROWS) { break; }
     *
     * if (state.CompletesToN(myColor, 4, topRow, c)) { myNumCompletes4++; } if
     * (state.CompletesToN(opponentColor, 4, topRow, c)) {
     * opponentNumCompletes4++; }
     *
     * }
     *
     * if (myNumCompletes4 > 0) { features[f++] = myNumCompletes4 - 1; } if
     * (opponentNumCompletes4 > 0) { features[f++] = -opponentNumCompletes4 + 1;
     * }
     *
     * return f;
    }
     */
    /**
     * @param state
     * @param f index
     * @param features (out)the state feature
     * @param myColor
     * @return feature index after update
     */
    int extractSequenceLengthHistogramFeatures(FIARState state, int[] features, Integer f, Color myColor, int signum) {
        int[] counts = new int[Consts.MAX_COLS + 1];
        int lengths[][] = new int[3][3];
        int[] sumLengths = new int[4];
        CellState myCellState = CellState.translate(myColor);

        for (int r = 0; r < Consts.MAX_ROWS; ++r) {
            for (int c = 0; c < Consts.MAX_COLS; ++c) {
                if (state.getCellState(c, r) == myCellState) {
                    // check sequences length for every cell that is mine in all 9 directions
                    for (int dr = -1; dr < 2; ++dr) {
                        for (int dc = -1; dc < 2; ++dc) {
                            if (dr == 0 && dc == 0) {
                                continue;
                            }
                            lengths[dr + 1][dc + 1] = state.getSequenceLengthInDirection(r, c, dr, dc, myCellState);
                        }
                    }

                    // opposite directions sums up (except current cell that's counted twice)
                    sumLengths[0] = lengths[0][0] + lengths[2][2] - 1; // bottom left to top right diag
                    sumLengths[1] = lengths[0][2] + lengths[2][0] - 1; // bottom right to top left diag
                    sumLengths[2] = lengths[0][1] + lengths[2][1] - 1; // vertical
                    sumLengths[3] = lengths[1][0] + lengths[1][2] - 1; // horizontal

                    // add to histogram
                    for (int k = 0; k < 4; ++k) {
                        ++counts[sumLengths[k]];
                    }
                }
            }
        }

        // every seqeunce is counted each time we see a member of it. so n-seq is counted n times.
        for (int i = 1; i < counts.length; ++i) {
            counts[i] /= i;
        }

        // 1-seq
        features[f++] = signum * counts[1];
        // 2-seq
        features[f++] = signum * counts[2];
        // 3-seq
        features[f++] = signum * counts[3];
        return f;
    }

    /**
     * extracts if we have a threat on an even row and all columns are with even
     * number of pieces
     *
     * @param state
     * @param f index
     * @param features (out)the state feature
     * @param myColor
     * @return feature index after update
     */
    int extractZugzwangFeature(FIARState state, int[] features, Integer f, Color myColor, int signum) {
        // do all columns contain even rows
        boolean allEven = true;
        boolean evenThreat = false;
        for (Integer legalMove : state.getLegalMoves()) {
            allEven = allEven && (state.getFirstFreeIndexOfColumn(legalMove) % 2 == 0);
        }

        if (allEven) {
            // check even rows starting with top of each column and check if it completes to 4
            for (Integer legalMove : state.getLegalMoves()) {
                int top = state.getFirstFreeIndexOfColumn(legalMove);

                // make sure we're at an even row
                if (top % 2 != 0) {
                    top++;
                }

                // search for an even threat
                for (; top < Consts.MAX_ROWS; top += 2) {
                    if (state.CompletesToN(myColor, 4, top, legalMove)) {
                        evenThreat = true;
                        break;
                    }
                }
            }
        }

        features[f++] = (evenThreat && allEven ? signum : 0);
        return f;
    }
}
