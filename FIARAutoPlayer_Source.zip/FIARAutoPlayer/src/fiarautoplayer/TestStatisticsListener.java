package fiarautoplayer;

/**
 * 
 * @author Shanee Lavi
 */
public interface TestStatisticsListener {

    /*
     * a function that will be called after each game is finished in a testing
     * session. The updates that will be done when a game is over is depended on
     * the way the function is implemented in the implementing class
     */
    public void onGameOver(Color firstPlayerColor, Color winnerColor);
}
